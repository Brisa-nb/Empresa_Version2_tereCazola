<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Esencia extends CI_Controller {
    public function __construct(){
    parent::__construct();
    $this->load->model('mP');
}

    public function mision(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_proposito']=$this->mP->consultar_proposito(1);
	    $this->load->view('esencia/mision',$datos); 
        $this->load->view('secciones/footer');
    } 

    public function vision(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_proposito']=$this->mP->consultar_proposito(2);
	    $this->load->view('esencia/vision',$datos);
        $this->load->view('secciones/footer');
    } 

    public function valores(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_proposito']=$this->mP->consultar_proposito(3);
	    $this->load->view('esencia/valores',$datos);
        $this->load->view('secciones/footer'); 
    } 
}
