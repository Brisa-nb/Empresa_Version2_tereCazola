<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Seccion_model', 'mSeccion');
        $this->load->model('Producto_model');
    }

    // Vista principal del administrador
    public function index() {
        $this->load->view('administrador/vista/admin_header');
        $this->load->view('administrador/vista/index'); 
        $this->load->view('administrador/vista/footer');
    }

    // --- SECCIONES ---
    public function secciones() {
        $this->load->view('administrador/vista/admin_header');
        $this->load->view('administrador/vista/secciones_view');
        $this->load->view('administrador/vista/footer');
    }

    public function listarSecciones() {
        $data = $this->mSeccion->listarActivas();
        echo json_encode($data);
    }

    // --- PRODUCTOS ---
    public function productos() {
        $this->load->view('administrador/vista/admin_header');
        $this->load->view('administrador/vista/productos_view');  
        $this->load->view('administrador/vista/footer');
    }

    public function listarProductos() {
        $data = $this->mProducto->listarActivos();
        echo json_encode($data);
    }
}