<!DOCTYPE html>
<html>
<head>
  <title>HOJALDRAS</title>
  <meta charset="UTF-8">
</head>
<body>
<div class='container-fluid' style="text-align:center;">
    <div class='row'>
        <div class='col-md-12'>
<?php
if (!empty($productos)) {
    foreach($productos as $item) {
        // Mostrar el nombre con el estilo solicitado
        echo '<div style="width:100%; background:rgba(75,0,130,0.7); color:#fff; text-align:center; font-size:2.5em; font-weight:bold; text-shadow:2px 2px 8px #000; padding:25px 0; margin-top:90px; position:relative; z-index:2;">';
        echo '</div>';
        echo $item->nombre_producto."<br>";
        echo "<img src='".base_url().$item->ruta.$item->archivo."' alt='" . htmlspecialchars($item->nombre_producto) . "' style='max-width:300px; height:auto;'/><br>";
        echo "<br>";
        echo $item->descripcion."<br>";
        echo "$".$item->precio." MXN<br>";

    } 
} else {
    echo "No hay datos";
}
?>
</div>
</div>
</div>
</body>
</html>