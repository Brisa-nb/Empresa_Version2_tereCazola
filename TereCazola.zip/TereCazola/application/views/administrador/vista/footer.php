
<nav class="layout-footer footer"> ... </nav>
</body>
</html>

<nav class="layout-footer footer" style="background:#e2cef6; border-top:3px solid #4b0082;">
    <div class="container-fluid d-flex flex-column align-items-center text-center py-3">

        <!-- Logo -->
        <img src="<?php echo base_url('assets/img/logo2.png'); ?>" 
             alt="Logo Tere Cazola" 
             style="height:45px; margin-bottom:6px;">

        <div class="d-flex flex-wrap justify-content-center" style="color:#4b0082; font-weight:600;">
            <a href="#" class="footer-link mx-3" style="color:#4b0082;">Nosotros</a>
            <a href="#" class="footer-link mx-3" style="color:#4b0082;">Ayuda</a>
            <a href="#" class="footer-link mx-3" style="color:#4b0082;">Contacto</a>
            <a href="#" class="footer-link mx-3" style="color:#4b0082;">Términos & Condiciones</a>
        </div>

        <div style="color:#4b0082; margin-top:5px;">
            &copy; <?php echo date('Y'); ?> Tere Cazola — Panel Administrativo
        </div>

    </div>
</nav>

