<h1>Vista de Secciones </h1>
<p>Esta vista se cargó correctamente desde el controlador Admin.php</p>

