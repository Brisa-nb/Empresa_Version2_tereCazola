<div class="container-fluid flex-grow-1 container-p-y">
    <h4 class="font-weight-bold py-3 mb-0">Dashboard de Administración Limpio</h4>

    <div class="row">
        <div class="col-12">
            <div class="card p-5 text-center">
                <h2 class="text-primary">TERE CAZOLA</h2>
                <p class="lead">Esta es la plantilla limpia.</p>
            </div>
        </div>
    </div>
</div>
