<style>
  .carousel-container {
    position: relative;
    overflow: hidden;
    width: 100%;
    background-color: #fafafa;
    padding: 20px 0;
  }

  .carousel-track {
    display: flex;
    gap: 20px;
    transition: transform 0.6s ease;
  }

  .product-card {
    flex: 0 0 33.3333%; /* 3 productos visibles */
    background: white;
    border-radius: 15px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    text-align: center;
    padding: 10px;
  }

  .product-card img {
    width: 100%;
    border-radius: 10px;
  }

  .carousel-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: #4b0082;
    color: white;
    border: none;
    font-size: 24px;
    padding: 8px 12px;
    border-radius: 50%;
    cursor: pointer;
    z-index: 2;
  }

  .carousel-btn.left { left: 10px; }
  .carousel-btn.right { right: 10px; }

  .carousel-btn:hover {
    background-color: #6a0dad;
  }

  .ver-mas {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #4b0082;
    font-weight: bold;
    text-decoration: underline;
  }

  @media (max-width: 768px) {
    .product-card {
      flex: 0 0 100%; /* En móvil, uno por vista */
    }
  }
</style>

<div id="about" class="container-fluid">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:20px;">LOS FAVORITOS DEL CLIENTE</h2>

  <div class="carousel-container">
    <button class="carousel-btn left" onclick="moveSlide(-1)">&#10094;</button>

    <div class="carousel-track" id="carouselTrack">
      <div class="product-card">
        <img src="assets/imagenes/hojaldras.jpg" alt="Hojaldras">
        <h4><a href="<?=base_url('productos/hojaldra')?>" style="color:#4b0082;">HOJALDRAS</a></h4>
        <p style="color:#4b0082;">$120.00 MXN</p>
      </div>

      <div class="product-card">
        <img src="assets/imagenes/rosca.jpg" alt="Rosca Brioche Extra Queso">
        <h4><a href="<?=base_url('productos/roscaB')?>" style="color:#4b0082;">ROSCA BRIOCHE EXTRA QUESO</a></h4>
        <p style="color:#4b0082;">$295.00 MXN</p>
      </div>

      <div class="product-card">
        <img src="assets/imagenes/bizcocho.jpg" alt="Biscocho Inglés">
        <h4><a href="<?=base_url('productos/biscochoI')?>" style="color:#4b0082;">BISCOCHO INGLÉS</a></h4>
        <p style="color:#4b0082;">$180.00 MXN</p>
      </div>

      <div class="product-card">
        <img src="assets/imagenes/bolitas.jpg" alt="Bolitas de Queso">
        <h4><a href="<?=base_url('productos/bolitasQ')?>" style="color:#4b0082;">BOLITAS DE QUESO</a></h4>
        <p style="color:#4b0082;">$150.00 MXN</p>
      </div>
    </div>

    <button class="carousel-btn right" onclick="moveSlide(1)">&#10095;</button>
  </div>

  <a href="<?= base_url('menu') ?>" class="ver-mas">Ver más productos...</a>
</div>

<script>
  const track = document.getElementById('carouselTrack');
  let cards = Array.from(track.children);
  const visibleSlides = 3;
  let index = visibleSlides;

  // Duplicar los productos al inicio y final (para efecto infinito)
  track.prepend(...cards.slice(-visibleSlides).map(card => card.cloneNode(true)));
  track.append(...cards.slice(0, visibleSlides).map(card => card.cloneNode(true)));
  cards = Array.from(track.children);

  // Ajustar la posición inicial
  track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;

  function moveSlide(direction) {
    index += direction;
    track.style.transition = 'transform 0.6s ease';
    track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;

    // Recolocar cuando se llega a un extremo
    track.addEventListener('transitionend', () => {
      if (index >= cards.length - visibleSlides) {
        index = visibleSlides;
        track.style.transition = 'none';
        track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;
      } else if (index <= 0) {
        index = cards.length - (visibleSlides * 2);
        track.style.transition = 'none';
        track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;
      }
    }, { once: true });
  }
</script>
