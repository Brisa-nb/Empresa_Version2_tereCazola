<div id="services" class="container-fluid text-center">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:40px;">
    Un Legado de Amor, Dulzura y Tradición
  </h2>
    <div class="row" style="text-align:center;">
        <video src="assets/videos/bucle.mp4" autoplay muted loop style="width:100%; max-height:400px; object-fit:cover; display:block; margin:0 auto;">
        </video>
    </div>
</div>
