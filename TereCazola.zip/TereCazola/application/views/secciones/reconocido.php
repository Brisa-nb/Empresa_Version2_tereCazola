<div id="recognitions" class="container-fluid text-center">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:40px;">
    RECONOCIDOS MUNDIALMENTE
  </h2>
  <div class="banner-img" style="position:relative; z-index:1;">
    <img src="assets/imagenes/sellos.png" alt="Reconocimientos" style="width:100%; height:45vh; object-fit:cover; display:block; margin:0 auto;">
  </div>
</div>
