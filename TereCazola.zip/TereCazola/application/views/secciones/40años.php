<div style="width:100%; background:rgba(75,0,130,0.7); color:#ffdf00; text-align:center; font-size:2.5em; font-weight:bold; text-shadow:2px 2px 8px #000; padding:40px 0; margin-top:90px; position:relative; z-index:2;">
  “CELEBRAMOS 40 AÑOS DE TRADICIÓN Y SABOR”
</div>

<video src="assets/videos/celebremos.mp4" autoplay muted loop style="width:100%; max-height:600px; object-fit:cover; display:block; margin:0 auto;">
  Tu navegador no soporta el video.
</video>