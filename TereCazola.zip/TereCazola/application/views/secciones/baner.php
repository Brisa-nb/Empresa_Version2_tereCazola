<div style="width:100%; background:#ffd700; color:#fff; text-align:center; font-size:2.5em; font-weight:bold; text-shadow:2px 2px 8px #000; padding:25px 0; margin-top:90px; position:relative; z-index:2;">
  “Compra, disfruta y comparte lo más dulce.”
</div>
<div class="banner-img" style="position:relative; z-index:1;">
  <img src="assets/imagenes/principal.png" alt="Logo Tere Cazola" style="width:100vw; height:60vh; object-fit:cover; display:block; margin:0 auto;">
</div>
