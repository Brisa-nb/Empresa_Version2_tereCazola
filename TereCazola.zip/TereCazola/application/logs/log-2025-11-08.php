<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-08 00:53:59 --> 404 Page Not Found: Admin/index
ERROR - 2025-11-08 00:56:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Seccion_model C:\laragon\www\TereCazola\system\core\Loader.php 314
