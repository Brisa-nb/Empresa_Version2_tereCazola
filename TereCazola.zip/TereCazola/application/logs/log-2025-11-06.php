<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-06 03:57:18 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\laragon\www\TereCazolaJB\application\views\productos\hojaldra.php 14
ERROR - 2025-11-06 03:57:36 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\laragon\www\TereCazolaJB\application\views\productos\hojaldra.php 14
ERROR - 2025-11-06 04:01:56 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazolaJB\application\views\productos\hojaldra.php 12
