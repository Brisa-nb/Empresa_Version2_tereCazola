<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-12 21:26:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Seccion_model C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-12 21:28:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Seccion_model C:\laragon\www\TereCazola\system\core\Loader.php 314
