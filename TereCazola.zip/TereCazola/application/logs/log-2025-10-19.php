<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-19 02:11:41 --> Severity: error --> Exception: Call to undefined function odbc_connect() C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:13:14 --> Severity: error --> Exception: Call to undefined function odbc_connect() C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:13:15 --> Severity: error --> Exception: Call to undefined function odbc_connect() C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:19:55 --> Severity: error --> Exception: Call to undefined function odbc_connect() C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:19:57 --> Severity: error --> Exception: Call to undefined function odbc_connect() C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:22:28 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:22:28 --> Unable to connect to the database
ERROR - 2025-10-19 02:30:34 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:30:34 --> Unable to connect to the database
ERROR - 2025-10-19 02:30:37 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:30:37 --> Unable to connect to the database
ERROR - 2025-10-19 02:30:52 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:30:52 --> Unable to connect to the database
ERROR - 2025-10-19 02:30:53 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 02:30:53 --> Unable to connect to the database
ERROR - 2025-10-19 02:38:12 --> Severity: error --> Exception: Unknown database 'terecazola' C:\xampp\htdocs\TereCazolaJ\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-10-19 02:38:15 --> Severity: error --> Exception: Unknown database 'terecazola' C:\xampp\htdocs\TereCazolaJ\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-10-19 03:13:01 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:03 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:08 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:10 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:11 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:12 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:12 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:13 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:13:36 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "stricton", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 99
ERROR - 2025-10-19 03:16:59 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:17:02 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:17:03 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:17:04 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:17:05 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:17:06 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:18:56 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 78
ERROR - 2025-10-19 03:20:20 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:20:22 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:20:56 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:20:57 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:20:58 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:20:59 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:21:03 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:21:04 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:22:05 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:22:06 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 82
ERROR - 2025-10-19 03:23:11 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 83
ERROR - 2025-10-19 03:27:33 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:27:35 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:27:36 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:28:11 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:28:13 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:28:14 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:28:15 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:28:15 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:28:18 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 84
ERROR - 2025-10-19 03:30:55 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 86
ERROR - 2025-10-19 03:31:13 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "cachedir", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 86
ERROR - 2025-10-19 03:31:14 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "cachedir", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 86
ERROR - 2025-10-19 03:33:20 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 88
ERROR - 2025-10-19 03:34:39 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 91
ERROR - 2025-10-19 03:36:00 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 93
ERROR - 2025-10-19 03:40:55 --> Severity: error --> Exception: syntax error, unexpected token "/", expecting end of file C:\xampp\htdocs\TereCazolaJ\application\config\database.php 96
ERROR - 2025-10-19 03:40:57 --> Severity: error --> Exception: syntax error, unexpected token "/", expecting end of file C:\xampp\htdocs\TereCazolaJ\application\config\database.php 96
ERROR - 2025-10-19 03:40:58 --> Severity: error --> Exception: syntax error, unexpected token "/", expecting end of file C:\xampp\htdocs\TereCazolaJ\application\config\database.php 96
ERROR - 2025-10-19 03:41:20 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:41:20 --> Unable to connect to the database
ERROR - 2025-10-19 03:46:57 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:46:57 --> Unable to connect to the database
ERROR - 2025-10-19 03:47:09 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:47:09 --> Unable to connect to the database
ERROR - 2025-10-19 03:47:12 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:47:12 --> Unable to connect to the database
ERROR - 2025-10-19 03:47:26 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:47:26 --> Unable to connect to the database
ERROR - 2025-10-19 03:48:09 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:48:09 --> Unable to connect to the database
ERROR - 2025-10-19 03:48:11 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:48:11 --> Unable to connect to the database
ERROR - 2025-10-19 03:48:13 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:48:13 --> Unable to connect to the database
ERROR - 2025-10-19 03:49:26 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "dbprefix", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 81
ERROR - 2025-10-19 03:49:27 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "dbprefix", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 81
ERROR - 2025-10-19 03:49:28 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "dbprefix", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 81
ERROR - 2025-10-19 03:52:36 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Login failed for user 'BRISA\pbarv'., SQL state 28000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:52:36 --> Unable to connect to the database
ERROR - 2025-10-19 03:53:47 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Login failed for user 'sa'., SQL state 28000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 03:53:47 --> Unable to connect to the database
ERROR - 2025-10-19 03:55:32 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:55:34 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:58:01 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:58:02 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 03:58:03 --> Severity: error --> Exception: syntax error, unexpected identifier " ", expecting ")" C:\xampp\htdocs\TereCazolaJ\application\config\database.php 77
ERROR - 2025-10-19 04:01:32 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:01:32 --> Unable to connect to the database
ERROR - 2025-10-19 04:36:46 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:36:46 --> Unable to connect to the database
ERROR - 2025-10-19 04:36:48 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:36:48 --> Unable to connect to the database
ERROR - 2025-10-19 04:36:49 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:36:49 --> Unable to connect to the database
ERROR - 2025-10-19 04:38:03 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:38:03 --> Unable to connect to the database
ERROR - 2025-10-19 04:38:05 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:38:05 --> Unable to connect to the database
ERROR - 2025-10-19 04:38:06 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:38:06 --> Unable to connect to the database
ERROR - 2025-10-19 04:38:07 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:38:07 --> Unable to connect to the database
ERROR - 2025-10-19 04:38:08 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:38:08 --> Unable to connect to the database
ERROR - 2025-10-19 04:38:09 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:38:09 --> Unable to connect to the database
ERROR - 2025-10-19 04:41:53 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:41:53 --> Unable to connect to the database
ERROR - 2025-10-19 04:41:55 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:41:55 --> Unable to connect to the database
ERROR - 2025-10-19 04:41:56 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:41:56 --> Unable to connect to the database
ERROR - 2025-10-19 04:41:59 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:41:59 --> Unable to connect to the database
ERROR - 2025-10-19 04:42:00 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:42:00 --> Unable to connect to the database
ERROR - 2025-10-19 04:42:01 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:42:01 --> Unable to connect to the database
ERROR - 2025-10-19 04:43:08 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:43:08 --> Unable to connect to the database
ERROR - 2025-10-19 04:43:09 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:43:09 --> Unable to connect to the database
ERROR - 2025-10-19 04:43:10 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:43:10 --> Unable to connect to the database
ERROR - 2025-10-19 04:43:11 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:43:11 --> Unable to connect to the database
ERROR - 2025-10-19 04:43:11 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][Administrador de controladores ODBC] No se encuentra el nombre del origen de datos y no se especific� ning�n controlador predeterminado, SQL state IM002 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:43:11 --> Unable to connect to the database
ERROR - 2025-10-19 04:45:12 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:45:12 --> Unable to connect to the database
ERROR - 2025-10-19 04:48:19 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:48:19 --> Unable to connect to the database
ERROR - 2025-10-19 04:54:52 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Login failed for user 'BRISA\pnarv'., SQL state 28000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:54:52 --> Unable to connect to the database
ERROR - 2025-10-19 04:55:58 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Login failed for user 'sa'., SQL state 28000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:55:58 --> Unable to connect to the database
ERROR - 2025-10-19 04:58:01 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Login failed for user 'BRISA\pnarv'., SQL state 28000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:58:01 --> Unable to connect to the database
ERROR - 2025-10-19 04:58:54 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Login failed for user 'sa'., SQL state 28000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 04:58:54 --> Unable to connect to the database
ERROR - 2025-10-19 05:01:40 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Cannot open database &quot;terecazola&quot; requested by the login. The login failed., SQL state 37000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 05:01:40 --> Unable to connect to the database
ERROR - 2025-10-19 05:15:02 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Cannot open database &quot;terecazola&quot; requested by the login. The login failed., SQL state 37000 in SQLConnect C:\xampp\htdocs\TereCazolaJ\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-19 05:15:02 --> Unable to connect to the database
