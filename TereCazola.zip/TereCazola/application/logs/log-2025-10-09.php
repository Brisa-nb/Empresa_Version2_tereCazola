<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-09 15:37:37 --> 404 Page Not Found: Inicio/menu
ERROR - 2025-10-09 15:37:53 --> 404 Page Not Found: Inicio/menu
ERROR - 2025-10-09 15:38:00 --> 404 Page Not Found: Men%C3%BA/index
ERROR - 2025-10-09 15:59:01 --> 404 Page Not Found: RoscaB/index
ERROR - 2025-10-09 16:00:15 --> 404 Page Not Found: RoscaB/index
ERROR - 2025-10-09 16:01:25 --> 404 Page Not Found: RoscaB/index
ERROR - 2025-10-09 16:01:50 --> 404 Page Not Found: RoscaB/index
ERROR - 2025-10-09 16:37:56 --> 404 Page Not Found: Productos/TiendaL_roscaB
ERROR - 2025-10-09 16:38:10 --> 404 Page Not Found: Tiendal/roscaB
ERROR - 2025-10-09 16:38:27 --> 404 Page Not Found: Productos/TiendaL_roscaB
ERROR - 2025-10-09 16:38:39 --> 404 Page Not Found: Productos/TiendaL_roscaB
ERROR - 2025-10-09 16:38:48 --> 404 Page Not Found: Tiendal/roscaB
ERROR - 2025-10-09 16:39:08 --> 404 Page Not Found: Tiendal/roscaB
ERROR - 2025-10-09 16:39:19 --> 404 Page Not Found: Productos/TiendaL_roscaB
ERROR - 2025-10-09 16:40:04 --> 404 Page Not Found: Productos/TiendaL_roscaB
ERROR - 2025-10-09 16:40:18 --> 404 Page Not Found: Productos/TiendaL_roscaB
