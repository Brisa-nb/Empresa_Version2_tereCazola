<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-10 07:35:30 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 7
ERROR - 2025-10-10 07:35:33 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 7
ERROR - 2025-10-10 07:39:47 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 7
ERROR - 2025-10-10 07:40:43 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:40:44 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:46 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:47 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:48 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:48 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:48 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:51 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:41:58 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:42:05 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:42:06 --> Severity: Compile Error --> Cannot use temporary expression in write context C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:43:51 --> Severity: Warning --> Undefined property: Inicio::$mP C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:43:51 --> Severity: error --> Exception: Call to a member function consultar_seccion() on null C:\laragon\www\TereCazola\application\controllers\Inicio.php 11
ERROR - 2025-10-10 07:52:37 --> Severity: error --> Exception: Unable to locate the model you have specified: MP C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-10-10 08:05:06 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:07:39 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:07:43 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:07:47 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:07:51 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:21 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:23 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:23 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:23 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:23 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:24 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:24 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:24 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:24 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:08:24 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:09:37 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:11:16 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:11:26 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:14:05 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 2
ERROR - 2025-10-10 08:18:05 --> Severity: error --> Exception: Unmatched '}' C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 16
ERROR - 2025-10-10 16:49:19 --> Severity: Warning --> Undefined variable $idclasificacion C:\laragon\www\TereCazola\application\models\MP.php 28
ERROR - 2025-10-10 16:57:33 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\laragon\www\TereCazola\application\views\productos\roscaB.php 19
ERROR - 2025-10-10 17:40:56 --> 404 Page Not Found: Productos/biscochoI
ERROR - 2025-10-10 17:41:21 --> 404 Page Not Found: Productos/biscochoI
ERROR - 2025-10-10 17:41:22 --> 404 Page Not Found: Productos/biscochoI
ERROR - 2025-10-10 17:41:22 --> 404 Page Not Found: Productos/biscochoI
ERROR - 2025-10-10 17:41:24 --> 404 Page Not Found: Productos/biscochoI
ERROR - 2025-10-10 17:44:03 --> 404 Page Not Found: Productos/biscochoI
ERROR - 2025-10-10 20:27:53 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\laragon\www\TereCazola\application\views\productos\bolitasQ.php 15
ERROR - 2025-10-10 20:29:08 --> Severity: error --> Exception: syntax error, unexpected token "<" C:\laragon\www\TereCazola\application\views\productos\bolitasQ.php 15
ERROR - 2025-10-10 20:41:54 --> 404 Page Not Found: Esencia/mision
ERROR - 2025-10-10 20:41:58 --> 404 Page Not Found: Esencia/vision
ERROR - 2025-10-10 20:42:02 --> 404 Page Not Found: Esencia/valores
ERROR - 2025-10-10 20:42:05 --> 404 Page Not Found: Esencia/valores
ERROR - 2025-10-10 20:42:08 --> 404 Page Not Found: Esencia/vision
ERROR - 2025-10-10 20:50:05 --> Severity: Warning --> Undefined variable $item C:\laragon\www\TereCazola\application\views\productos\bolitasQ.php 11
ERROR - 2025-10-10 20:50:05 --> Severity: Warning --> Attempt to read property "nombre" on null C:\laragon\www\TereCazola\application\views\productos\bolitasQ.php 11
