<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-13 23:52:04 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_submenu_x_idmenu'., SQL state 37000 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-13 23:52:04 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_submenu_x_idmenu'. - Invalid query: exec pa_consultar_submenu_x_idmenu @idmenu='3'
ERROR - 2025-11-13 23:53:16 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_submenu_x_idmenu'., SQL state 37000 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-13 23:53:16 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_submenu_x_idmenu'. - Invalid query: exec pa_consultar_submenu_x_idmenu @idmenu='3'
