<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-05 20:35:41 --> 404 Page Not Found: Index/welcome
ERROR - 2025-09-05 20:43:26 --> 404 Page Not Found: Principal/index
ERROR - 2025-09-05 20:44:59 --> 404 Page Not Found: Principal/index
ERROR - 2025-09-05 20:50:39 --> 404 Page Not Found: Principal/index
ERROR - 2025-09-05 21:57:45 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting variable C:\xampp\htdocs\empresa\application\controllers\Welcome.php 5
ERROR - 2025-09-05 22:00:17 --> 404 Page Not Found: Index/index
ERROR - 2025-09-05 22:00:23 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting variable C:\xampp\htdocs\empresa\application\controllers\Welcome.php 5
ERROR - 2025-09-05 22:11:47 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:11:47 --> Severity: Warning --> Attempt to read property "Id" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:11:47 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:11:47 --> Severity: Warning --> Attempt to read property "nombre_seccion" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:11:47 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:24:28 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:28 --> Severity: Warning --> Attempt to read property "Id" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:28 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:28 --> Severity: Warning --> Attempt to read property "nombre_seccion" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:28 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Attempt to read property "Id" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Attempt to read property "nombre_seccion" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:30 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Attempt to read property "Id" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Attempt to read property "nombre_seccion" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:30 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Attempt to read property "Id" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:30 --> Severity: Warning --> Attempt to read property "nombre_seccion" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:24:30 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:26:08 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:26:08 --> Severity: Warning --> Attempt to read property "Id" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 81
ERROR - 2025-09-05 22:26:08 --> Severity: Warning --> Undefined variable $item C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:26:08 --> Severity: Warning --> Attempt to read property "nombre_seccion" on null C:\xampp\htdocs\empresa\application\views\welcome_message.php 82
ERROR - 2025-09-05 22:26:08 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:30:40 --> Severity: error --> Exception: Call to undefined function convertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-09-05 22:45:00 --> Severity: error --> Exception: Call to undefined function covertir_estatus() C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
