<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-14 00:16:47 --> 404 Page Not Found: Admin/sucursales
ERROR - 2025-11-14 04:13:54 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'productos'., SQL state S0002 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-14 04:13:54 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'productos'. - Invalid query: SELECT *
FROM productos
WHERE estado = 'activo'
ERROR - 2025-11-14 04:17:09 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'producto'., SQL state S0002 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-14 04:17:09 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'producto'. - Invalid query: SELECT *
FROM producto
WHERE estado = 'activo'
ERROR - 2025-11-14 04:29:53 --> Severity: Warning --> Undefined property: Admin::$mProducto C:\laragon\www\TereCazola\application\controllers\Admin.php 39
ERROR - 2025-11-14 04:29:53 --> Severity: error --> Exception: Call to a member function listarActivos() on null C:\laragon\www\TereCazola\application\controllers\Admin.php 39
ERROR - 2025-11-14 04:32:37 --> Severity: Warning --> Undefined property: Admin::$mProducto C:\laragon\www\TereCazola\application\controllers\Admin.php 39
ERROR - 2025-11-14 04:32:37 --> Severity: error --> Exception: Call to a member function listarActivos() on null C:\laragon\www\TereCazola\application\controllers\Admin.php 39
ERROR - 2025-11-14 04:34:04 --> Severity: Warning --> Undefined property: Admin::$mProducto C:\laragon\www\TereCazola\application\controllers\Admin.php 39
ERROR - 2025-11-14 04:34:04 --> Severity: error --> Exception: Call to a member function listarActivos() on null C:\laragon\www\TereCazola\application\controllers\Admin.php 39
