<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-17 04:47:33 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:47:33 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:50:52 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:50:52 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:50:58 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:50:58 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:51:04 --> 404 Page Not Found: Esencia/assets
ERROR - 2025-10-17 04:51:04 --> 404 Page Not Found: Esencia/assets
ERROR - 2025-10-17 04:51:08 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:51:08 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:51:12 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:51:12 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:57:21 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 04:57:21 --> 404 Page Not Found: Productos/assets
ERROR - 2025-10-17 19:47:16 --> 404 Page Not Found: Productos/index
ERROR - 2025-10-17 19:47:38 --> 404 Page Not Found: Productos/index
ERROR - 2025-10-17 20:19:14 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\laragon\www\TereCazolaJ\TereCazola\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-17 20:19:14 --> Unable to connect to the database
