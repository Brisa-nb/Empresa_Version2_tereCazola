<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-31 14:22:25 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][DBNETLIB]No existe el servidor SQL Server o se ha denegado el acceso al mismo., SQL state 08001 in SQLConnect C:\laragon\www\TereCazolaJB\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-31 14:22:25 --> Unable to connect to the database
ERROR - 2025-10-31 14:25:49 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazolaJB\application\views\productos\roscaB.php 12
ERROR - 2025-10-31 14:25:55 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazolaJB\application\views\productos\biscochoI.php 12
ERROR - 2025-10-31 14:26:36 --> 404 Page Not Found: Inicio/Admin
ERROR - 2025-10-31 14:36:48 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazolaJB\application\views\productos\biscochoI.php 12
ERROR - 2025-10-31 14:39:38 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazolaJB\application\views\productos\biscochoI.php 12
ERROR - 2025-10-31 17:01:06 --> 404 Page Not Found: Amin/index
ERROR - 2025-10-31 20:45:55 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:47:34 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:48:07 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:49:23 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:50:00 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:50:17 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:50:18 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:50:26 --> 404 Page Not Found: Path/to
ERROR - 2025-10-31 20:50:45 --> 404 Page Not Found: Path/to
