<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Seccion_model extends CI_Model {

    public function listarActivas() {
        $query = $this->db->get_where('secciones', ['estado' => 'activo']);
        return $query->result_array();
    }
}
