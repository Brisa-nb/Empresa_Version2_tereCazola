<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producto_model extends CI_Model {

    public function listarActivos() {
        $query = $this->db->get_where('producto', ['estado' => 'activo']);
        return $query->result_array();
    }
}

