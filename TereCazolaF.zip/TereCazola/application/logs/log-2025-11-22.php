<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-22 03:52:29 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
ERROR - 2025-11-22 03:52:29 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
ERROR - 2025-11-22 03:52:30 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
ERROR - 2025-11-22 03:52:33 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
ERROR - 2025-11-22 03:52:39 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
ERROR - 2025-11-22 03:54:40 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
ERROR - 2025-11-22 03:54:49 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\laragon\www\TereCazola\system\core\Output.php 447
