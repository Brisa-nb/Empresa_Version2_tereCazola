<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-26 23:02:36 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver]Expir� el tiempo de espera de inicio de sesi�n, SQL state S1T00 in SQLConnect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-11-26 23:02:36 --> Unable to connect to the database
ERROR - 2025-11-26 23:56:36 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 730
ERROR - 2025-11-26 23:57:17 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 732
ERROR - 2025-11-26 23:57:18 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 732
ERROR - 2025-11-26 23:57:19 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 732
ERROR - 2025-11-26 23:57:19 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 732
ERROR - 2025-11-26 23:57:19 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 732
