ableable02<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-27 00:21:57 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\laragon\www\TereCazola\application\views\Tere_Sucursales.php 731
ERROR - 2025-11-27 00:57:36 --> 404 Page Not Found: Admin/index
ERROR - 2025-11-27 00:57:52 --> 404 Page Not Found: Inicio/admin
ERROR - 2025-11-27 00:58:01 --> 404 Page Not Found: Admin/index
ERROR - 2025-11-27 00:58:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Seccion_model C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-27 00:58:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Seccion_model C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-27 00:58:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Seccion_model C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-27 02:17:09 --> Severity: Compile Error --> Cannot redeclare Consultas_model::consultar_clasificacion() C:\laragon\www\TereCazola\application\models\Consultas_model.php 79
ERROR - 2025-11-27 02:27:52 --> Severity: Compile Error --> Cannot redeclare Consultas_model::consultar_clasificacion() C:\laragon\www\TereCazola\application\models\Consultas_model.php 38
ERROR - 2025-11-27 02:29:18 --> Severity: Warning --> Undefined variable $productos C:\laragon\www\TereCazola\application\views\Tere_TiendaL.php 31
ERROR - 2025-11-27 02:42:09 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 27
ERROR - 2025-11-27 02:44:04 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'productos'., SQL state S0002 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-27 02:44:04 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'productos'. - Invalid query: SELECT idproducto, nombre_producto, descripcion, precio, ruta, archivo 
            FROM productos 
            WHERE estatus = 1 
            ORDER BY nombre_producto ASC
ERROR - 2025-11-27 03:23:52 --> 404 Page Not Found: Inicio/admin
