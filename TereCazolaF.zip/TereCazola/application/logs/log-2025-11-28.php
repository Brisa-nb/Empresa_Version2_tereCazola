<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-28 02:11:59 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver]Expir� el tiempo de espera de inicio de sesi�n, SQL state S1T00 in SQLConnect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-11-28 02:11:59 --> Unable to connect to the database
