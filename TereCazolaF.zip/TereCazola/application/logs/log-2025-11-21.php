<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-21 17:52:01 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 17:52:08 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 17:54:44 --> Severity: error --> Exception: Unable to locate the model you have specified: MP C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-21 17:54:47 --> Severity: error --> Exception: Unable to locate the model you have specified: MP C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-21 17:54:51 --> Severity: error --> Exception: Unable to locate the model you have specified: MP C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-21 17:56:45 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 17:59:55 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 18:00:13 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 18:00:15 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 18:00:18 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 18:02:14 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 18:03:43 --> 404 Page Not Found: Inicio/18
ERROR - 2025-11-21 18:09:15 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_por_id'., SQL state 37000 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-21 18:09:15 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_por_id'. - Invalid query: 
        EXEC pa_consultar_producto_por_id @idproducto = '19'
ERROR - 2025-11-21 18:09:52 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_por_id'., SQL state 37000 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-21 18:09:52 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_por_id'. - Invalid query: 
        EXEC pa_consultar_producto_por_id @idproducto = '19'
ERROR - 2025-11-21 18:14:27 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 18:14:33 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 18:15:34 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 18:15:35 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 18:15:38 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 18:15:40 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 18:18:09 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 18:18:10 --> 404 Page Not Found: Producto/ver
ERROR - 2025-11-21 19:01:57 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:02:06 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:02:12 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:02:17 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:11:05 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:11:08 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:17:53 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:17:54 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:18:34 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:25:56 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_x_id'., SQL state 37000 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-21 19:25:56 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_x_id'. - Invalid query: exec pa_consultar_producto_x_id @idproducto = '18'
ERROR - 2025-11-21 19:26:10 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_x_id'., SQL state 37000 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-21 19:26:10 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_producto_x_id'. - Invalid query: exec pa_consultar_producto_x_id @idproducto = '18'
ERROR - 2025-11-21 19:44:07 --> 404 Page Not Found: Inicio/Consulta_producto
ERROR - 2025-11-21 19:44:35 --> Severity: error --> Exception: Unable to locate the model you have specified: MP C:\laragon\www\TereCazola\system\core\Loader.php 314
ERROR - 2025-11-21 19:52:01 --> Severity: Warning --> Undefined property: Productos::$mP C:\laragon\www\TereCazola\application\controllers\Productos.php 12
ERROR - 2025-11-21 19:52:01 --> Severity: error --> Exception: Call to a member function consultar_producto_por_id() on null C:\laragon\www\TereCazola\application\controllers\Productos.php 12
ERROR - 2025-11-21 19:52:47 --> Severity: Warning --> Undefined property: Productos::$mP C:\laragon\www\TereCazola\application\controllers\Productos.php 31
ERROR - 2025-11-21 19:52:47 --> Severity: error --> Exception: Call to a member function consultar_producto_por_id() on null C:\laragon\www\TereCazola\application\controllers\Productos.php 31
ERROR - 2025-11-21 19:52:55 --> Severity: Warning --> Undefined property: Productos::$mP C:\laragon\www\TereCazola\application\controllers\Productos.php 31
ERROR - 2025-11-21 19:52:55 --> Severity: error --> Exception: Call to a member function consultar_producto_por_id() on null C:\laragon\www\TereCazola\application\controllers\Productos.php 31
