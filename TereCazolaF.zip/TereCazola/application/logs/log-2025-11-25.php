<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-25 23:28:27 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'sucursales'., SQL state S0002 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-25 23:28:27 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'sucursales'. - Invalid query: SELECT id_sucursal, nombre_sucursal, ciudad
FROM sucursales
ORDER BY nombre_sucursal ASC
ERROR - 2025-11-25 23:35:41 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'sucursales'., SQL state S0002 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-25 23:35:41 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'sucursales'. - Invalid query: SELECT id_sucursal, nombre_sucursal, ciudad
FROM sucursales
ORDER BY nombre_sucursal ASC
ERROR - 2025-11-25 23:38:20 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'sucursales'., SQL state S0002 in SQLExecDirect C:\laragon\www\TereCazola\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-11-25 23:38:20 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'sucursales'. - Invalid query: SELECT id_sucursal, nombre_sucursal, ciudad
FROM sucursales
ORDER BY nombre_sucursal ASC
ERROR - 2025-11-25 23:44:22 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
ERROR - 2025-11-25 23:44:26 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
ERROR - 2025-11-25 23:44:30 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
ERROR - 2025-11-25 23:44:35 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
ERROR - 2025-11-25 23:44:39 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
ERROR - 2025-11-25 23:44:43 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
ERROR - 2025-11-25 23:44:47 --> Severity: error --> Exception: Call to undefined method Consultas_model::obtener_productos() C:\laragon\www\TereCazola\application\controllers\Inicio.php 41
