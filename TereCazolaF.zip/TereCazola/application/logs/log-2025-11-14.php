<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-14 20:20:34 --> 404 Page Not Found: Productos/19
ERROR - 2025-11-14 20:30:55 --> 404 Page Not Found: Productos/ver
ERROR - 2025-11-14 20:33:10 --> 404 Page Not Found: Productos/ver
ERROR - 2025-11-14 20:35:03 --> 404 Page Not Found: Productos/ver
ERROR - 2025-11-14 20:35:07 --> 404 Page Not Found: Productos/ver
ERROR - 2025-11-14 20:36:58 --> 404 Page Not Found: Productos/ver
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$url_metodo C:\laragon\www\TereCazola\application\views\secciones\losfav.php 82
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$imagen C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\TereCazola\system\core\Config.php 335
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 90
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$url_metodo C:\laragon\www\TereCazola\application\views\secciones\losfav.php 82
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$imagen C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\TereCazola\system\core\Config.php 335
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 90
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$url_metodo C:\laragon\www\TereCazola\application\views\secciones\losfav.php 82
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$imagen C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\TereCazola\system\core\Config.php 335
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 90
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$url_metodo C:\laragon\www\TereCazola\application\views\secciones\losfav.php 82
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$imagen C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\TereCazola\system\core\Config.php 335
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 87
ERROR - 2025-11-14 20:44:00 --> Severity: Warning --> Undefined property: stdClass::$nombre C:\laragon\www\TereCazola\application\views\secciones\losfav.php 90
ERROR - 2025-11-14 20:47:54 --> 404 Page Not Found: Productos/producto_no_encontrado
ERROR - 2025-11-14 20:48:35 --> 404 Page Not Found: Productos/producto_no_encontrado
ERROR - 2025-11-14 20:51:26 --> 404 Page Not Found: Productos/producto_no_encontrado
ERROR - 2025-11-14 20:51:41 --> 404 Page Not Found: Productos/producto_no_encontrado
