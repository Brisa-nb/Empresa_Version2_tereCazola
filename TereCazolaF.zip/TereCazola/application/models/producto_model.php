<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producto_model extends CI_Model {

    public function listarActivos() {
        // Solo la tabla. CI ya está conectado a la base desde database.php
        $query = $this->db->query("SELECT * FROM cat_productos WHERE estatus = 1");
        return $query->result_array();
    }

    public function insertar($data) {
    return $this->db->insert('cat_productos', $data);
}
    public function obtenerPorId($id) {
    return $this->db->get_where('cat_productos', ['id' => $id])->row_array();
}
    public function actualizar($id, $data) {
    $this->db->where('id', $id);
    return $this->db->update('cat_productos', $data);
}

public function buscar($nombre) {
    $this->db->like('nombre', $nombre);
    $this->db->where('estatus', 1);
    return $this->db->get('cat_productos')->result_array();
}


}