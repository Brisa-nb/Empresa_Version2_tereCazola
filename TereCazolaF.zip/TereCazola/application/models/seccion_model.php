<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Seccion_model extends CI_Model {

    public function listarActivos() {
        return $this->db->get('cat_secciones')->result();
    }

    public function insertar($datos) {
        return $this->db->insert('cat_secciones', $datos);
    }

    public function obtener($id) {
        return $this->db->get_where('cat_secciones', ['id' => $id])->row();
    }

    public function actualizar($id, $datos) {
        $this->db->where('id', $id);
        return $this->db->update('cat_secciones', $datos);
    }

    public function eliminar($id) {
        $this->db->where('id', $id);
        return $this->db->delete('cat_secciones');
    }
}

