<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consultas_model extends CI_Model {
    /*function consultar_seccion(){
        $this->db->select("Id, nombre_seccion, activo");
        $this->db->from("cat_secciones");
        $this->db->where("activo","1");       
        $query=$this->db->get();
        if($query!=false){
            if($query->num_rows()>0){
                return $query->result();   
            }
        }else{
            return false;
        }      
    }*/
         function consultar_seccion($idcatmenu){
        $sql="exec pa_consultar_submenu_x_idmenu @idmenu='".$idcatmenu."'";
        $query=$this->db->query($sql);
        if($query!=false){
            return $query->result();
        }else{
            return false;
        }
    }
        function consultar_clasificacion($idclasificacion)
        {
        $sql = "EXEC pa_consultar_producto_x_idclasificacion @idclasificacion = ?";
        $query = $this->db->query($sql, array((int)$idclasificacion));

         if ($query !== false && $query->num_rows() > 0) {
         return $query->result();
            } else {
            return false;
        }
       }  /* 
        function consultar_clasificacion($idcatclasificacion){
        $sql="exec pa_consultar_producto_x_idclasificacion @idclasificacion='".$idcatclasificacion."'";
        $query=$this->db->query($sql);
        if($query!=false){
            return $query->result();
        }else{
            return false;
        }
    }*/
        function consultar_producto_por_nombre($nombre){
        $sql="exec pa_consultar_producto_por_nombre @nombre = '".$nombre."'";
        $query=$this->db->query($sql);
        if($query!= false){
            return $query->result();
    } else {
        return false;
        }
    }
        function consultar_proposito($idcatproposito){
        $sql="exec pa_consultar_identidad_x_idproposito @idproposito='".$idcatproposito."'";
        $query=$this->db->query($sql);
        if($query!=false){
            return $query->result();
        }else{
            return false;
        }
    }
    function consultar_favoritos() {
        $query = $this->db->query("EXEC pa_consultar_productos_favoritos");
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    function consultar_producto_por_id($idproducto) {
        $sql = "exec pa_consultar_producto_x_id @idproducto = ".$idproducto;
        $query = $this->db->query($sql);
        if ($query != false) {
            return $query->row();
        } else {
            return false;
        }
    }

  public function obtener_productos() {
    $sql = "
        SELECT 
            p.id AS idproducto,
            p.nombre AS nombre_producto,
            p.descripcion,
            p.precio,
            img.ruta,
            img.archivo
        FROM cat_productos p
        LEFT JOIN cat_imagenes img ON img.id = p.idcatimagen
        WHERE p.estatus = 1
        ORDER BY p.nombre ASC
    ";

    return $this->db->query($sql)->result();
}

}