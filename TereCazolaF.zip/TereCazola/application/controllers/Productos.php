<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Productos extends CI_Controller {
      public function __construct() {
        parent::__construct();
        $this->load->model('Consultas_model','mP'); // Carga el modelo
    }
        
    public function Consulta_Producto($idproducto = NULL){
        if($idproducto == NULL) {
            redirect('Inicio');
        }
        
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['prod'] = $this->mP->consultar_producto_por_id($idproducto);
        $this->load->view('productos/detalle_producto', $datos);
        $this->load->view('secciones/footer');
    }
}