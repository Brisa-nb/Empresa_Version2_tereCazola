<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Tiendal extends CI_Controller {
public function __construct(){
parent::__construct();
$this->load->model('Consultas_model','mP');
}


// Página principal de tienda
public function index(){
// Obtener todas las clasificaciones (categorías)
$datos['clasificaciones'] = $this->mP->consultar_todas_clasificaciones();


$this->load->view('secciones/header');
$this->load->view('secciones/menu');
$this->load->view('Tere_TiendaL', $datos);
$this->load->view('secciones/footer');
}


// Productos por categoría
public function categoria($idclasificacion = NULL){
if($idclasificacion == NULL){
redirect('Tiendal');
}


$datos['productos'] = $this->mP->consultar_clasificacion($idclasificacion);
$datos['clasificacion'] = $idclasificacion;


$this->load->view('secciones/header');
$this->load->view('secciones/menu');
$this->load->view('tienda/Tienda_Categoria', $datos);
$this->load->view('secciones/footer');
}
}