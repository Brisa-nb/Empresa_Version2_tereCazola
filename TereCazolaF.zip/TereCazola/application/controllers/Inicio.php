<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inicio extends CI_Controller {
    public function __construct(){
    parent::__construct();
    $this->load->model('Consultas_model','mP');
    $this->load->model('Seccion_model', 'mSeccion');
    }

    private function cargarHeaderMenu(){
        $data['secciones_menu'] = $this->mSeccion->listarActivos();
        $this->load->view('secciones/header', $data);
        $this->load->view('secciones/menu', $data);
    }

    public function index(){
        $this->cargarHeaderMenu();

        // -------------------------------------------------
        // SECCIÓN: BANNER (siempre visible)
        // -------------------------------------------------
        $this->load->view('secciones/baner');

        // -------------------------------------------------
        // FAVORITOS (ID = 1) → mostrar SOLO si está activo
        // -------------------------------------------------
        $favoritos = $this->mSeccion->obtener(1);

        if ($favoritos && $favoritos->estatus == 1) {
            $datos['favoritos'] = $this->mP->consultar_favoritos();
            $this->load->view('secciones/losfav', $datos);
        }

        // -------------------------------------------------
        // RESTO DE SECCIONES FIJAS
        // -------------------------------------------------
        $this->load->view('secciones/legado');
        $this->load->view('secciones/reconocido');
        $this->load->view('secciones/40años');

        // -------------------------------------------------
        // NUESTRA ESENCIA (ID = 2) → solo si está activa
        // -------------------------------------------------
        $esencia = $this->mSeccion->obtener(2);

        if ($esencia && $esencia->estatus == 1) {
            $this->load->view('secciones/nuestraescsen');
        }

        // -------------------------------------------------
        // CIERRE
        // -------------------------------------------------
        $this->load->view('secciones/terexd');
        $this->load->view('secciones/footer');
    }
    public function tiendal(){
    $this->load->view('secciones/header');
    $this->load->view('secciones/menu');
    $datos['titulo_seccion'] = $this->mP->consultar_seccion(2);
    $datos['productos']      = $this->mP->obtener_productos(); // <-- FALTA ESTO
    $this->load->view('Tere_TiendaL', $datos);
    $this->load->view('secciones/footer');
    
    } 

    public function menu(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(3);
	    $this->load->view('Tere_Menú',$datos);
        $this->load->view('secciones/footer');
    } 
    
    public function obtener_productos() {
        $this->output->enable_profiler(FALSE);
        $productos = $this->mP->obtener_productos();
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($productos));
    }

    public function blog(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(7);
	    $this->load->view('Tere_Blog',$datos);
        $this->load->view('secciones/footer'); 
    } 

    public function sucursales(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(4);
	    $this->load->view('Tere_Sucursales',$datos);
        $this->load->view('secciones/footer');
    } 

    public function conocenos(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(5);
	    $this->load->view('Tere_Conócenos',$datos);
        $this->load->view('secciones/footer');
    } 

    public function contacto(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(6);
	    $this->load->view('Tere_Contacto',$datos);
        $this->load->view('secciones/footer');   
    } 

    public function facturacion(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(8);
        $this->load->view('Tere_Facturación',$datos);
        $this->load->view('secciones/footer');
    }

    public function cargar_politica($tipo = NULL) {
        // Desabilitar output de vista automático
        $this->output->enable_profiler(FALSE);
        
        if($tipo == NULL) {
            $this->output->set_content_type('application/json');
            $this->output->set_output(json_encode(['error' => 'Tipo de política no especificada']));
            return;
        }

        // Definir los tipos de políticas disponibles
        $politicas = array(
            'privacidad' => 'Política de Privacidad',
            'reembolso' => 'Política de Reembolso',
            'envios' => 'Política de Envíos',
            'terminos' => 'Términos y Condiciones',
            'filosofia' => 'Filosofía de Tere Cazola'
        );

        // Validar que el tipo sea válido
        if(!array_key_exists($tipo, $politicas)) {
            $this->output->set_content_type('application/json');
            $this->output->set_output(json_encode(['error' => 'Tipo de política inválida']));
            return;
        }

        // Obtener el título
        $titulo = $politicas[$tipo];

        // Obtener el contenido HTML de la vista
        $contenido = $this->load->view('politicas/'.$tipo, NULL, TRUE);

        // Devolver JSON con título y contenido usando output de CodeIgniter
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode([
            'titulo' => $titulo,
            'contenido' => $contenido
        ]));
    }
}
