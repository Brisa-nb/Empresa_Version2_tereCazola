<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Seccion_model', 'mSeccion');
        $this->load->model('Producto_model', 'mProducto');
    }

    public function index() {
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/index');
        $this->load->view('administrador/vista/footer');
    }

    /* SECCIONES */
    public function secciones() {
        $data['secciones'] = $this->mSeccion->listarActivos();
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/secciones_view', $data);
        $this->load->view('administrador/vista/footer');
    }

    public function secciones_create() {
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/crear_seccion');
        $this->load->view('administrador/vista/footer');
    }

    public function secciones_store() {
        $datos = [
            'nombre'   => $this->input->post('nombre'),
            'estatus'  => $this->input->post('estatus'),
            'registro' => date('Y-m-d'),
            'uc'       => 'admin'
        ];

        $this->mSeccion->insertar($datos);
        redirect('admin/secciones');
    }

    public function secciones_edit($id) {
        $data['seccion'] = $this->mSeccion->obtener($id);
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/editar_seccion', $data);
        $this->load->view('administrador/vista/footer');
    }

    public function secciones_update() {
        $id = $this->input->post('id');

        $datos = [
            'nombre'  => $this->input->post('nombre'),
            'estatus' => $this->input->post('estatus')
        ];

        $this->mSeccion->actualizar($id, $datos);
        redirect('admin/secciones');
    }

    public function secciones_delete($id) {
        $this->mSeccion->eliminar($id);
        redirect('admin/secciones');
    }

    /* PRODUCTOS */
    public function productos() {
        $data['productos'] = $this->mProducto->listarActivos();
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/productos_view', $data);
        $this->load->view('administrador/vista/footer');
    }

    public function crearProducto() {
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/crear_producto');
        $this->load->view('administrador/vista/footer');
    }

    public function guardarProducto() {
        $datos = array(
            'nombre'      => $this->input->post('nombre'),
            'descripcion' => $this->input->post('descripcion'),
            'precio'      => $this->input->post('precio'),
            'estatus'     => $this->input->post('estatus')
        );

        $this->db->insert('cat_productos', $datos);
        redirect('admin/productos');
    }

    public function editarProducto($id) {
        $producto = $this->db->get_where('cat_productos', ['id' => $id])->row_array();
        if(!$producto) { show_404(); }

        $data['producto'] = $producto;
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/editar_producto', $data);
        $this->load->view('administrador/vista/footer');
    }

    public function actualizarProducto() {
        $id = $this->input->post('id');

        $datos = array(
            'nombre'      => $this->input->post('nombre'),
            'descripcion' => $this->input->post('descripcion'),
            'precio'      => $this->input->post('precio'),
            'estatus'     => $this->input->post('estatus')
        );

        $this->db->where('id', $id);
        $this->db->update('cat_productos', $datos);

        redirect('admin/productos');
    }

    public function eliminarProducto($id) {
        $this->db->where('id', $id);
        $this->db->delete('cat_productos');
        redirect('admin/productos');
    }

    public function infoProducto($id) {
        $producto = $this->db->get_where('cat_productos', ['id' => $id])->row_array();
        if(!$producto) { show_404(); }

        $data['producto'] = $producto;
        $data['secciones_menu'] = $this->mSeccion->listarActivos();

        $this->load->view('administrador/vista/admin_header', $data);
        $this->load->view('administrador/vista/info_producto', $data);
        $this->load->view('administrador/vista/footer');
    }
}