<!DOCTYPE html>
<html>
<head>
  <title>Facturación</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div style="text-align:center;">
    <?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {
            // Mostrar contenido HTML correctamente 
            echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' . html_entity_decode($item->contenido) . '</div>';
            echo '
              <div style="
                  width:300px;
                  margin:40px auto;
                  padding:20px;
                  border:2px dashed #4b0082;
                  border-radius:10px;
                  background:#f9f9f9;
                  font-family:monospace;
                  text-align:left;
                  color:#333;
              ">
                  <h3 style="text-align:center; margin-bottom:10px; color:#4b0082;">TICKET DE COMPRA</h3>
                  <p>Producto: </p>
                  <p>Cantidad: </p>
                  <p>Precio:   </p>
                  <hr>
                  <p><strong>Total: </strong></p>
                  <p style="text-align:center; margin-top:15px; font-size:0.9em;">Gracias por su compra</p>
              </div>
              ';
    }
} else {
    echo "No hay datos";
}
?>
</body>
</html>