<!DOCTYPE html>
<html>
 <title>Tienda en Línea</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
<br>
<br>
<br>
<br>
<div style="text-align:center;">
<?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {

        // Contenido del PA (ej: "CONTÁCTATE CON NOSOTROS")
        echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' 
                . html_entity_decode($item->contenido) . 
             '</div>';
    }
} else {
    echo "No hay datos";
}
?>

<div class="container" style="padding:30px 15px;">
  <div style="text-align:center; margin-bottom:20px;">
    <h1 style="color:#5b2c83; font-size:2.2rem; letter-spacing:1px; margin:0;">
      Productos
    </h1>
    <p style="color:#6f4fa6; margin-top:8px;">Explora nuestras delicias — hecho con amor Tere Cazola</p>
  </div>
  <?php if ($productos && is_array($productos) && count($productos) > 0): ?>
    <div class="grid" style="display:flex; flex-wrap:wrap; gap:22px; justify-content:center;">
      <?php foreach ($productos as $prod): 
            // Construir URL de imagen: si 'ruta' contiene // o http lo dejamos, si no usamos base_url
            $img_src = '';
            if (!empty($prod->ruta) && !empty($prod->archivo)) {
                if (strpos($prod->ruta, 'http') === 0 || strpos($prod->ruta, '//') === 0) {
                    $img_src = rtrim($prod->ruta, '/') . '/' . ltrim($prod->archivo, '/');
                } else {
                    // Fallback: asume ruta dentro de la CDN / carpeta
                    $img_src = base_url(trim($prod->ruta, '/')) . '/' . ltrim($prod->archivo, '/');
                }
            } else {
                // Imagen por defecto
                $img_src = base_url('assets/images/no-image.png');
            }

            // Precio formateado
            $precio = isset($prod->precio) ? number_format((float)$prod->precio, 2) : '0.00';
      ?>
        <div class="card-product" style="
            width:260px;
            border-radius:12px;
            overflow:hidden;
            background:#fff;
            box-shadow:0 6px 18px rgba(91,44,131,0.12);
            transition:transform .25s, box-shadow .25s;
            ">
          <a href="<?php echo base_url('Productos/Consulta_Producto/'.$prod->idproducto); ?>" style="text-decoration:none; color:inherit;">
            <div style="height:200px; background:#f6f0fb; display:flex; align-items:center; justify-content:center;">
              <img src="<?php echo $img_src; ?>" alt="<?php echo htmlentities($prod->nombre_producto); ?>" style="max-width:100%; max-height:100%; object-fit:contain;">
            </div>
            <div style="padding:14px;">
              <h3 style="font-size:1.05rem; color:#4b0082; margin:0 0 6px; min-height:44px;"><?php echo htmlentities(utf8_encode($prod->nombre_producto)); ?>
              <p style="color:#666; font-size:0.92rem; height:42px; overflow:hidden; margin:0 0 10px;"><?php echo strip_tags(substr(utf8_encode($prod->descripcion),0,120)); ?><?php echo (strlen($prod->descripcion) > 120) ? '...' : ''; ?>
              <div style="display:flex; align-items:center; justify-content:space-between;">
                <span style="font-weight:700; color:#5b2c83;">$ <?php echo $precio; ?> MXN</span>
                <button style="background:linear-gradient(90deg,#5b2c83,#8a41d6); color:#fff; border:none; padding:8px 12px; border-radius:8px; cursor:pointer;">Ver</button>
              </div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p style="text-align:center; color:#666; padding:40px 0;">No hay productos disponibles en esta categoría.</p>
  <?php endif; ?>

  <style>
    .card-product:hover{
      transform: translateY(-6px) scale(1.01);
      box-shadow:0 18px 36px rgba(91,44,131,0.18);
    }

    @media (max-width: 800px){
      .card-product{ width:45% !important; }
    }
    @media (max-width: 480px){
      .card-product{ width:100% !important; }
    }
  </style>
</div>