<!DOCTYPE html>
<html>
<head>
  <title>BLOG - Tere Cazola</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
      background: white; 
      min-height: 100vh; 
      padding: 20px; 
    }

    .container { max-width: 1200px; margin: 0 auto; }

    /* Header */
    .header { 
      text-align: center; 
      color: #5d3a8a; 
      margin: 80px 0 50px; 
      animation: slideDown 0.6s ease-out; 
    }
    .header h1 { 
      font-size: 3.5em; 
      text-shadow: 2px 2px 4px rgba(93,58,138,0.1); 
      margin-bottom: 10px; 
      font-weight: bold; 
    }
    .header p { 
      font-size: 1.3em; 
      color: #7d5ba8; 
      opacity: 0.9; 
    }

    /* Buscador */
    .search-section { 
      display: flex; 
      justify-content: center; 
      gap: 10px; 
      margin-bottom: 40px; 
      flex-wrap: wrap; 
    }
    .search-input { 
      padding: 12px 20px; 
      border: 2px solid #ffc107; 
      border-radius: 25px; 
      width: 300px; 
      font-size: 1em; 
      box-shadow: 0 4px 15px rgba(255,193,7,0.2); 
      background: white; 
      color: #333; 
    }
    .search-input::placeholder { color: #a699b8; }

    /* Filtros */
    .filter-buttons { 
      display: flex; 
      justify-content: center; 
      gap: 15px; 
      margin-bottom: 40px; 
      flex-wrap: wrap; 
    }
    .filter-btn { 
      padding: 10px 25px; 
      border: 2px solid #ffc107; 
      background: white; 
      color: #5d3a8a; 
      border-radius: 25px; 
      cursor: pointer; 
      font-size: 1em; 
      font-weight: bold; 
      transition: all 0.3s ease; 
    }
    .filter-btn:hover,
    .filter-btn.active { 
      background: #ffc107; 
      color: #5d3a8a; 
      transform: translateY(-3px); 
      box-shadow: 0 6px 20px rgba(255,193,7,0.4); 
    }

    /* Grid */
    .blog-grid { 
      display: grid; 
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); 
      gap: 30px; 
      margin-bottom: 50px; 
    }

    /* Cards */
    .blog-card { 
      background: white; 
      border-radius: 15px; 
      overflow: hidden; 
      box-shadow: 0 10px 30px rgba(93,58,138,0.12); 
      transition: all 0.3s ease; 
      animation: fadeIn 0.5s ease-out; 
      border: 2px solid #f0e6ff; 
    }
    .blog-card:hover { 
      transform: translateY(-10px); 
      box-shadow: 0 15px 40px rgba(93,58,138,0.2); 
      border-color: #ffc107; 
    }

    .card-image { 
      width: 100%; 
      height: 250px; 
      background: linear-gradient(135deg, #7d5ba8 0%, #5d3a8a 100%); 
      display: flex; 
      align-items: center; 
      justify-content: center; 
      font-size: 80px; 
    }

    .card-content { padding: 25px; }

    .card-type { 
      display: inline-block; 
      padding: 5px 15px; 
      border-radius: 20px; 
      font-size: 0.75em; 
      font-weight: bold; 
      margin-bottom: 10px; 
      text-transform: uppercase; 
    }

    .card-type.producto { background: #ffc107; color: #5d3a8a; }
    .card-type.noticia { background: #e8d5f2; color: #5d3a8a; }

    .card-title { 
      font-size: 1.5em; 
      color: #5d3a8a; 
      margin-bottom: 10px; 
      font-weight: bold; 
    }

    .card-date { color: #999; font-size: 0.9em; margin-bottom: 15px; }

    .card-description { 
      color: #666; 
      line-height: 1.6; 
      margin-bottom: 20px; 
      font-size: 0.95em; 
    }

    .card-highlight { 
      background: #f9f5ff; 
      padding: 15px; 
      border-left: 4px solid #ffc107; 
      margin-bottom: 15px; 
      border-radius: 5px; 
      color: #555; 
      font-weight: 500; 
    }

    .read-more { 
      display: inline-block; 
      background: linear-gradient(135deg, #ffc107 0%, #ffb300 100%); 
      color: #5d3a8a; 
      padding: 10px 20px; 
      border-radius: 20px; 
      text-decoration: none; 
      font-weight: bold; 
      transition: all 0.3s ease; 
      border: none; 
      cursor: pointer; 
    }
    .read-more:hover { 
      background: linear-gradient(135deg, #5d3a8a 0%, #7d5ba8 100%); 
      color: #ffc107; 
      transform: translateX(5px); 
      box-shadow: 0 6px 20px rgba(93,58,138,0.3); 
    }

    /* No resultados */
    .no-results { 
      text-align: center; 
      color: #5d3a8a; 
      font-size: 1.3em; 
      padding: 40px; 
      background: #f9f5ff; 
      border-radius: 15px; 
      box-shadow: 0 10px 30px rgba(93,58,138,0.1); 
    }

    /* Animaciones */
    @keyframes slideDown { 
      from { opacity: 0; transform: translateY(-30px); } 
      to { opacity: 1; transform: translateY(0); } 
    }

    @keyframes fadeIn { 
      from { opacity: 0; transform: scale(0.95); } 
      to { opacity: 1; transform: scale(1); } 
    }

    /* Responsive */
    @media (max-width: 768px) { 
      .header h1 { font-size: 2.5em; } 
      .blog-grid { grid-template-columns: 1fr; } 
      .search-input { width: 100%; } 
    }
  </style>

</head>
<body>
  <br>
<br>
<br>
<br>
<br>
<div style="text-align:center;">
<?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {

            // Mostrar contenido HTML correctamente 
            echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' . html_entity_decode($item->contenido) . '</div>';
    }
} else {
    echo "No hay datos";
}
?>    <!-- BUSCADOR -->
    <div class="search-section">
      <input type="text" class="search-input" id="searchInput" placeholder="Buscar productos o noticias...">
    </div>

    <!-- BOTONES FILTRO -->
    <div class="filter-buttons">
      <button class="filter-btn active" data-filter="all">Todos</button>
      <button class="filter-btn" data-filter="padre">Día del Padre</button>
      <button class="filter-btn" data-filter="madre">Día de la Madre</button>
      <button class="filter-btn" data-filter="boda">Bodas</button>
      <button class="filter-btn" data-filter="cumpleaños">Cumpleaños</button>
      <button class="filter-btn" data-filter="navidad">Navidad</button>
      <button class="filter-btn" data-filter="noticias">Noticias</button>
    </div>

    <!-- GRID DE BLOG -->
    <div class="blog-grid" id="blogGrid">
      <?php
        $items = [
          ['cat' => 'padre', 'type' => 'Producto', 'emoji' => '🧁', 'title' => 'Pastel Chocolate Robusto', 'date' => 'Junio 2024', 'desc' => 'Pastel de chocolate...', 'highlight' => '🎯 Ideal para: El Día del Padre...'],
          ['cat' => 'padre', 'type' => 'Producto', 'emoji' => '🥃', 'title' => 'Pie de Nuez Pecan', 'date' => 'Junio 2024', 'desc' => 'Delicioso pie...', 'highlight' => '🎯 Ideal para: Un postre clásico...'],
          ['cat' => 'madre', 'type' => 'Producto', 'emoji' => '🌸', 'title' => 'Torta Frutos Rojos', 'date' => 'Mayo 2024', 'desc' => 'Bizcocho esponjoso...', 'highlight' => '🎯 Ideal para: Día de la Madre...'],
          ['cat' => 'madre', 'type' => 'Producto', 'emoji' => '🍰', 'title' => 'Cheesecake Frutos Silvestres', 'date' => 'Mayo 2024', 'desc' => 'Cheesecake cremoso...', 'highlight' => '🎯 Ideal para consentir...'],
          ['cat' => 'boda', 'type' => 'Producto', 'emoji' => '💒', 'title' => 'Pastel de Boda Elegante', 'date' => 'Todo el año', 'desc' => 'Pastel 3 pisos...', 'highlight' => '🎯 Ideal para bodas...'],
          ['cat' => 'boda', 'type' => 'Producto', 'emoji' => '💍', 'title' => 'Cupcakes Personalizados', 'date' => 'Todo el año', 'desc' => 'Cupcakes individuales...', 'highlight' => '🎯 Ideal para invitados...'],
          ['cat' => 'cumpleaños', 'type' => 'Producto', 'emoji' => '🎂', 'title' => 'Pastel Temático', 'date' => 'Todo el año', 'desc' => 'Pastel diseñado...', 'highlight' => '🎯 Ideal cumpleaños...'],
          ['cat' => 'cumpleaños', 'type' => 'Producto', 'emoji' => '🧁', 'title' => 'Caja de Brownies', 'date' => 'Todo el año', 'desc' => 'Combo perfecto...', 'highlight' => '🎯 Ideal como regalo...'],
          ['cat' => 'navidad', 'type' => 'Producto', 'emoji' => '🎄', 'title' => 'Roscón de Reyes', 'date' => 'Dic - Ene 2024', 'desc' => 'Roscón esponjoso...', 'highlight' => '🎯 Tradición navideña...'],
          ['cat' => 'navidad', 'type' => 'Producto', 'emoji' => '❄️', 'title' => 'Turrón Artesanal', 'date' => 'Diciembre 2024', 'desc' => 'Surtido navideño...', 'highlight' => '🎯 Regalo elegante...'],
          ['cat' => 'noticias', 'type' => 'Noticia', 'emoji' => '📰', 'title' => '40 Años Tere Cazola', 'date' => 'Octubre 2024', 'desc' => 'Anunciamos 40 años...', 'highlight' => '📌 Descuentos todo octubre.'],
          ['cat' => 'noticias', 'type' => 'Noticia', 'emoji' => '🏪', 'title' => 'Nueva Sucursal', 'date' => 'Septiembre 2024', 'desc' => 'Inauguramos Plaza Mayor...', 'highlight' => '📌 Ofertas lanzamiento.'],
          ['cat' => 'noticias', 'type' => 'Noticia', 'emoji' => '👨‍🍳', 'title' => 'Nuevo Chef Internacional', 'date' => 'Agosto 2024', 'desc' => 'Bienvenido Chef Jorge...', 'highlight' => '📌 Próxima cata exclusiva.'],
          ['cat' => 'noticias', 'type' => 'Noticia', 'emoji' => '🌱', 'title' => 'Sostenibilidad', 'date' => 'Julio 2024', 'desc' => 'Ingredientes orgánicos...', 'highlight' => '📌 Plantamos un árbol...'],
          ['cat' => 'noticias', 'type' => 'Noticia', 'emoji' => '🚚', 'title' => 'Entrega Express', 'date' => 'Junio 2024', 'desc' => 'Entrega mismo día...', 'highlight' => '📌 Envío gratis + $50.'],
        ];

        foreach($items as $item) {
          $typeClass = ($item['type'] === 'Producto') ? 'producto' : 'noticia';

          echo "
          <div class='blog-card' data-category='{$item['cat']}'>
            <div class='card-image'>{$item['emoji']}</div>
            <div class='card-content'>
              <span class='card-type {$typeClass}'>{$item['type']}</span>
              <h2 class='card-title'>{$item['title']}</h2>
              <p class='card-date'>{$item['date']}</p>
              <p class='card-description'>{$item['desc']}</p>
              <div class='card-highlight'><strong>{$item['highlight']}</strong></div>
              <a href='#' class='read-more'>".($item['type']==='Producto'?'Ver Detalles':'Leer Más')."</a>
            </div>
          </div>";
        }
      ?>
    </div>

    <!-- SIN RESULTADOS -->
    <div id="noResults" class="no-results" style="display: none;">
      No se encontraron productos o noticias que coincidan con tu búsqueda.
    </div>

  </div>

  <!-- JS -->
  <script>
    const filterBtns = document.querySelectorAll('.filter-btn');
    const blogCards = document.querySelectorAll('.blog-card');
    const searchInput = document.getElementById('searchInput');
    const noResults = document.getElementById('noResults');

    function filterCards() {
      const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;
      const searchTerm = searchInput.value.toLowerCase();
      let visibleCount = 0;

      blogCards.forEach(card => {
        const matchFilter = activeFilter === 'all' || card.dataset.category === activeFilter;
        const matchSearch = card.textContent.toLowerCase().includes(searchTerm);

        if (matchFilter && matchSearch) {
          card.style.display = 'block';
          visibleCount++;
        } else {
          card.style.display = 'none';
        }
      });

      noResults.style.display = visibleCount === 0 ? 'block' : 'none';
    }

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelector('.filter-btn.active').classList.remove('active');
        btn.classList.add('active');
        filterCards();
      });
    });

    searchInput.addEventListener('input', filterCards);
  </script>

</body>
</html>