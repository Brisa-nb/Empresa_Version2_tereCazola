<div class="container" style="margin-top: 40px; margin-bottom: 40px;">
    <div class="row">
        <?php 
        if(isset($prod) && !empty($prod)){
        ?>
            <div class="col-md-6">
                <img src="<?=base_url().$prod->ruta.$prod->archivo?>" alt="<?=$prod->nombre_producto?>" style="width: 100%; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
            </div>
            <div class="col-md-6">
                <h2 style="color: #4b0082; font-weight: bold; margin-bottom: 20px;"><?=$prod->nombre_producto?></h2>
                
                <div style="background-color: #f5f5f5; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h3 style="color: #4b0082; margin-bottom: 10px;">Precio</h3>
                    <p style="font-size: 28px; color: #d9534f; font-weight: bold;">$<?=$prod->precio?></p>
                </div>

                <div style="margin-bottom: 20px;">
                    <h3 style="color: #4b0082; margin-bottom: 10px;">Descripción</h3>
                    <p><?=isset($prod->descripcion) ? $prod->descripcion : 'Sin descripción disponible'?></p>
                </div>

                <div style="margin-bottom: 20px;">
                    <h3 style="color: #4b0082; margin-bottom: 10px;">Información</h3>
                    <ul style="list-style-type: none; padding-left: 0;">
                        <li><strong>Categoría:</strong> <?=isset($prod->nombre_clasificacion) ? $prod->nombre_clasificacion : 'N/A'?></li>
                        <li><strong>Estado:</strong> <span style="color: green;">Disponible</span></li>
                    </ul>
                </div>

                <div style="margin-bottom: 20px;">
                    <button class="btn" style="background-color: #4b0082; color: white; padding: 12px 30px; font-size: 16px; border: none; border-radius: 5px; cursor: pointer;">
                        Agregar al Carrito
                    </button>
                </div>

                <div style="margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;">
                    <a href="<?=base_url('menu')?>" style="color: #4b0082; text-decoration: underline; font-weight: bold;">← Volver al Menú</a>
                </div>
            </div>
        <?php
        } else {
        ?>
            <div class="alert alert-warning" style="margin-top: 20px;">
                <p>Producto no encontrado.</p>
                <a href="<?=base_url('menu')?>" class="btn btn-primary">Volver al Menú</a>
            </div>
        <?php
        }
        ?>
    </div>
</div>
