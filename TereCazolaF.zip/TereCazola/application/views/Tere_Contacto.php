<!DOCTYPE html>
<html>
<head>
  <title>Tienda en Línea</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
<br>
<br>
<br>
<br>
<br>
<div style="text-align:center;">
<?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {

        // Contenido del PA (ej: "CONTÁCTATE CON NOSOTROS")
        echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' 
                . html_entity_decode($item->contenido) . 
             '</div>';
    }
} else {
    echo "No hay datos";
}
?>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre = htmlspecialchars($_POST['nombre']);
        $email = htmlspecialchars($_POST['email']);
        $mensaje = htmlspecialchars($_POST['mensaje']);

        echo "<p style='color:green; font-size:1.3em; font-weight:bold; margin-top:25px;'>
                ¡Gracias por escribirnos, $nombre!<br>
                En un momento te consentimos con una respuesta deliciosa. 🍰💜
              </p>";
    }
    ?>
    <form method="POST" style="margin-top:20px;">
        <input type="text" name="nombre" placeholder="Tu nombre" required
               style="padding:10px; width:300px; margin:10px; border:2px solid #4b0082; border-radius:8px;"><br>

        <input type="email" name="email" placeholder="Tu email" required
               style="padding:10px; width:300px; margin:10px; border:2px solid #4b0082; border-radius:8px;"><br>

        <textarea name="mensaje" placeholder="Escribe tu mensaje" required
               style="padding:10px; width:300px; height:120px; margin:10px; border:2px solid #4b0082; border-radius:8px;"></textarea><br>

        <button type="submit" 
                style="background:#4b0082; color:white; padding:12px 25px; border:none; border-radius:8px; cursor:pointer; font-size:1em;">
            Enviar
        </button>
    </form>
</div>

</div>
</body>
</html>