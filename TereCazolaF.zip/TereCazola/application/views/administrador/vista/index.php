<div class="container mt-4">

    <!-- BIENVENIDA -->
    <div class="text-center mb-4">
        <img src="<?php echo base_url('assets/img/logo6.png'); ?>" style="height:80px;">
        <h2 class="mt-3" style="color:#4b0082; font-weight:bold;">
            Bienvenido al Panel Administrativo
        </h2>
        <p class="text-muted">
            Gestiona productos, secciones y contenido del sitio.
        </p>
    </div>

    <!-- TARJETAS DE ESTADÍSTICAS -->
    <div class="row">

        <!-- PRODUCTOS -->
        <div class="col-md-3">
            <div class="card text-white mb-3 pointer" 
                 style="background:#7a2bbf; cursor:pointer;"
                 onclick="window.location='<?php echo site_url('admin/productos'); ?>'">
                <div class="card-body text-center">
                    <i class="feather icon-package" style="font-size:32px; color:white;"></i>
                    <h5 class="card-title mt-2">Productos</h5>
                </div>
            </div>
        </div>

        <!-- SECCIONES -->
        <div class="col-md-3">
            <div class="card text-white mb-3 pointer" 
                 style="background:#9c27b0; cursor:pointer;"
                 onclick="window.location='<?php echo site_url('admin/secciones'); ?>'">
                <div class="card-body text-center">
                    <i class="feather icon-layers" style="font-size:32px; color:white;"></i>
                    <h5 class="card-title mt-2">Secciones</h5>
                </div>
            </div>
        </div>

    </div>


 <!-- Accesos rápidos -->
<button onclick="window.location='<?= site_url('admin/crearProducto'); ?>'"
    class="btn btn-primary m-2 d-flex align-items-center gap-2" 
    style="background:#7a2bbf; border:none;">
    <i class="feather icon-plus-circle"></i> Crear Producto
</button>

<button onclick="window.location='<?= base_url('admin/secciones_create'); ?>';"
    class="btn btn-dark m-2 d-flex align-items-center gap-2" 
    style="background:#9c27b0; border:none;">
    <i class="feather icon-edit"></i> Crear Sección
</button>


    </div>

</div>

