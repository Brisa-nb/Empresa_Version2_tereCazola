<<div class="container mt-4">
    <h3>Editar Producto</h3>

    <form action="<?php echo site_url('admin/actualizarProducto'); ?>" method="post">
        <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">

        <div class="form-group mt-3">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control" value="<?php echo $producto['nombre']; ?>" required>
        </div>

        <div class="form-group mt-3">
            <label>Descripción:</label>
            <textarea name="descripcion" class="form-control" required><?php echo $producto['descripcion']; ?></textarea>
        </div>

        <div class="form-group mt-3">
            <label>Precio:</label>
            <input type="number" step="0.01" name="precio" class="form-control" value="<?php echo $producto['precio']; ?>" required>
        </div>

        <div class="form-group mt-3">
            <label>Estatus:</label>
            <select name="estatus" class="form-control">
                <option value="1" <?php echo ($producto['estatus'] == 1) ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo ($producto['estatus'] == 0) ? 'selected' : ''; ?>>Inactivo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary mt-4">Actualizar Producto</button>
        <a href="<?php echo site_url('admin/productos'); ?>" class="btn btn-secondary mt-4">Cancelar</a>
    </form>
</div>
