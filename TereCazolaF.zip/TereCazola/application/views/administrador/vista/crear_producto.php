<div class="container mt-4">
    <h3>Crear Nuevo Producto</h3>

    <form action="<?php echo site_url('admin/guardarProducto'); ?>" method="post">

        <div class="form-group mt-3">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="form-group mt-3">
            <label>Descripción:</label>
            <textarea name="descripcion" class="form-control" required></textarea>
        </div>

        <div class="form-group mt-3">
            <label>Precio:</label>
            <input type="number" step="0.01" name="precio" class="form-control" required>
        </div>

        <div class="form-group mt-3">
            <label>Estatus:</label>
            <select name="estatus" class="form-control">
                <option value="1">Activo</option>
                <option value="0">Inactivo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success mt-4">Guardar Producto</button>
        <a href="<?php echo site_url('admin/productos'); ?>" class="btn btn-secondary mt-4">Cancelar</a>
    </form>
</div>
