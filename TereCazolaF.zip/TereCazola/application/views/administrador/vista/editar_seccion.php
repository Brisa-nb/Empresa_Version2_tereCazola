<div class="container mt-4">
    <h3>Editar Sección</h3>

    <form action="<?php echo site_url('admin/secciones_update'); ?>" method="post">

        <!-- ID oculto -->
        <input type="hidden" name="id" value="<?php echo $seccion->id; ?>">

        <div class="form-group mt-3">
            <label>Nombre:</label>
            <input type="text" name="nombre" value="<?php echo $seccion->nombre; ?>" class="form-control" required>
        </div>

        <div class="form-group mt-3">
            <label>Estatus:</label>
            <select name="estatus" class="form-control">
                <option value="1" <?php echo ($seccion->estatus == 1 ? 'selected' : ''); ?>>Activo</option>
                <option value="0" <?php echo ($seccion->estatus == 0 ? 'selected' : ''); ?>>Inactivo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary mt-4">Actualizar</button>
        <a href="<?php echo site_url('admin/secciones'); ?>" class="btn btn-secondary mt-4">Cancelar</a>

    </form>
</div>
