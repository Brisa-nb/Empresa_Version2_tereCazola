<!DOCTYPE html>
<html lang="en" class="material-style layout-fixed">

<head>
    <title>Panel Administrativo | Tere Cazola</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">

    <meta name="description" content="Panel de administración de Tere Cazola" />
    <meta name="keywords" content="administrador, cms, mvc">
    <meta name="author" content="Brisa" />

    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/img/favicon.ico'); ?>">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

    <!-- ICONOS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/fontawesome.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/ionicons.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/linearicons.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/open-iconic.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/pe-icon-7-stroke.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/feather.css'); ?>">

    <!-- ESTILOS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-material.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/shreerang-material.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/uikit.css'); ?>">

    <link rel="stylesheet" href="<?php echo base_url('assets/libs/perfect-scrollbar/perfect-scrollbar.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/libs/flot/flot.css'); ?>">

    <!-- BOOTSTRAP EXTRA -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        .sidenav-inner .sidenav-link,
        .sidenav-inner .sidenav-header {
            color: #e2cef6 !important;
        }

        .sidenav-icon {
            color: #e2cef6 !important;
        }

        .sidenav-item:hover > .sidenav-link {
            background: #7a2bbf !important;
            color: white !important;
        }

        .sidenav-item.active > .sidenav-link {
            background: #7a2bbf !important;
            color: white !important;
        }

        .layout-navbar {
            background: #e2cef6 !important;
            border-bottom: 3px solid #4b0082;
        }
    </style>
</head>

<body>
    <div class="page-loader">
        <div class="bg-primary"></div>
    </div>

    <div class="layout-wrapper layout-2">
        <div class="layout-inner">

            <!-- ====== SIDENAV ====== -->
            <div id="layout-sidenav" class="layout-sidenav sidenav sidenav-vertical" style="background:#4b0082;">

                <div class="app-brand demo">
                    <span class="app-brand-logo demo">
                        <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="Logo Tere Cazola" style="height:45px;">
                    </span>

                    <a href="<?php echo site_url('admin'); ?>" 
                    class="app-brand-text demo sidenav-text font-weight-normal ml-2 text-white">
                     TERE CAZOLA
                    </a>

                    <a href="javascript:" class="layout-sidenav-toggle sidenav-link text-large ml-auto">
                        <i class="ion ion-md-menu align-middle"></i>
                    </a>
                </div>

                <div class="sidenav-divider mt-0"></div>

                <ul class="sidenav-inner py-1">

                    <li class="sidenav-header small font-weight-semibold">Gestión de Contenido</li>

                    <!-- Página Principal -->
                    <li class="sidenav-item active">
                        <a href="<?php echo site_url('admin'); ?>" class="sidenav-link">
                            <i class="sidenav-icon feather icon-home"></i>
                            <div>Pagina Principal</div>
                        </a>
                    </li>

                    <!-- PRODUCTOS -->
                    <li class="sidenav-item">
                        <a href="<?php echo site_url('admin/productos'); ?>" class="sidenav-link">
                            <i class="sidenav-icon feather icon-tag"></i>
                            <div>Productos</div>
                        </a>

                        <ul class="sidenav-menu">
                            <li class="sidenav-item">
                                <a href="<?php echo site_url('admin/crearProducto'); ?>" class="sidenav-link">
                                    <div>Crear Nuevo</div>
                                </a>
                            </li>

                            <li class="sidenav-item">
                                <a href="<?php echo site_url('admin/productos'); ?>" class="sidenav-link">
                                    <div>Listar y Editar</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!-- SECCIONES -->
                    <li class="sidenav-item">
                        <a href="<?php echo site_url('admin/secciones'); ?>" class="sidenav-link">
                            <i class="sidenav-icon feather icon-layers"></i>
                            <div>Secciones</div>
                        </a>

                        <!-- SECCIONES DINÁMICAS -->
                        <?php if (!empty($secciones_menu)): ?>
                        <ul class="sidenav-menu">
                            <?php foreach ($secciones_menu as $sec): ?>
                                <li class="sidenav-item">
                                    <a href="#" class="sidenav-link">
                                        <div><?php echo $sec->nombre; ?></div>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>

                    </li>

                </ul>
            </div>

            <div class="layout-container">
                <nav class="layout-navbar navbar navbar-expand-lg align-items-lg-center bg-white container-p-x" id="layout-navbar"></nav>
                <div class="layout-content">
