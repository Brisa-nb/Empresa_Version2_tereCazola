<div class="container mt-4">

    <h3 class="mb-4">Gestión de Productos</h3>

    <!-- Botón Crear Producto -->
    <a href="<?php echo site_url('admin/crearProducto'); ?>" 
       class="btn btn-success mb-3">+ Crear Producto</a>

    <div class="row">
        <div class="col-xl-12 col-sm-12 col-lg-12 table-responsive">
            <table id="tablaProductos" class="table table-striped table-borderless border-bottom border-light dataTable no-footer table-condensed compact">
                <thead>
                    <tr>
                        <th width="5%">ID</th>
                        <th width="10%">Nombre</th>
                        <th width="5%">Precio</th>
                        <th width="5%">Estado</th>
                        <th width="20%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($productos)): ?>
                        <?php foreach ($productos as $producto): ?>
                            <tr>
                                <td><?php echo $producto['id']; ?></td>
                                <td><?php echo $producto['nombre']; ?></td>
                                <td><?php echo $producto['precio']; ?></td>
                                <td>
                                    <?php echo ($producto['estatus'] == 1) ? 'Activo' : 'Inactivo'; ?>
                                </td>
                                <td style="white-space: nowrap;">
                                    <!-- Botones de acción -->
                                    <a href="<?php echo site_url('admin/editarProducto/'.$producto['id']); ?>" 
                                       class="btn btn-sm btn-primary">Editar</a>
                                    <a href="<?php echo site_url('admin/eliminarProducto/'.$producto['id']); ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('¿Seguro que deseas eliminar este producto?');">Eliminar</a>
                                    <a href="<?php echo site_url('admin/infoProducto/'.$producto['id']); ?>" 
                                       class="btn btn-sm btn-info">Info</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>


<!-- DataTables -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function() {
    $('#tablaProductos').DataTable({
        language: {
            url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json"
        },
        columnDefs: [
            { orderable: false, targets: 4 } // La columna "Acciones" no es ordenable
        ]
    });
});
</script>
