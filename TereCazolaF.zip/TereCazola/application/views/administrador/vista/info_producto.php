<div class="container mt-4">
    <h3>Información del Producto</h3>

    <table class="table">
        <tr>
            <th>Nombre</th>
            <td><?php echo $producto['nombre']; ?></td>
        </tr>
        <tr>
            <th>Descripción</th>
            <td><?php echo $producto['descripcion']; ?></td>
        </tr>
        <tr>
            <th>Precio</th>
            <td><?php echo $producto['precio']; ?></td>
        </tr>
    </table>

    <a href="<?php echo site_url('admin/productos'); ?>" class="btn btn-secondary">Volver</a>
</div>
