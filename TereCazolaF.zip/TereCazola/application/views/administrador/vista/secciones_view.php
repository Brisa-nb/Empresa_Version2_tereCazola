<div class="container mt-4">

    <h3 class="mb-4">Gestión de Secciones</h3>

    <a href="<?= base_url('admin/secciones_create'); ?>" class="btn btn-success mb-3">
        + Crear Sección
    </a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Estatus</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($secciones as $s): ?>
                <tr>
                    <td><?= $s->id ?></td>
                    <td><?= $s->nombre ?></td>
                    <td><?= $s->estatus == 1 ? 'Activo' : 'Inactivo' ?></td>
                    <td>
                        <a href="<?= base_url('admin/secciones_edit/'.$s->id); ?>" class="btn btn-warning btn-sm">Editar</a>
                        <a href="<?= base_url('admin/secciones_delete/'.$s->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar sección?');">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</div>
