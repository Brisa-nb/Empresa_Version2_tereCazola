<div class="container mt-4">
    <h3>Crear Nueva Sección</h3>

    <form action="<?= base_url('admin/secciones_store'); ?>" method="post">

        <div class="form-group mt-3">
            <label>Nombre de la sección:</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="form-group mt-3">
            <label>Estatus:</label>
            <select name="estatus" class="form-control">
                <option value="1">Activo</option>
                <option value="0">Inactivo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success mt-4">Guardar Sección</button>
        <a href="<?= base_url('admin/secciones'); ?>" class="btn btn-secondary mt-4">Cancelar</a>
    </form>
</div>
