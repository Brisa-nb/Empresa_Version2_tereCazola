<div class="politica-content">
    <h3 style="color: #4b0082; margin-bottom: 20px;">Política de Privacidad</h3>
    <p>En Repostería Tere Cazola, nos comprometemos a proteger tu privacidad. Esta política describe cómo recopilamos, usamos y protegemos tu información personal.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Recopilación de Información</h4>
    <p>Recopilamos información que voluntariamente proporcionas al realizar compras, registrarte en nuestro sitio o contactarnos. Esta información incluye:</p>
    <ul>
        <li>Nombre y apellido</li>
        <li>Correo electrónico</li>
        <li>Teléfono</li>
        <li>Dirección de envío</li>
        <li>Información de pago</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Uso de la Información</h4>
    <p>Utilizamos tu información para:</p>
    <ul>
        <li>Procesar y entregar tus pedidos</li>
        <li>Mejorar nuestros servicios</li>
        <li>Enviarte actualizaciones sobre productos</li>
        <li>Responder a tus consultas</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Protección de Datos</h4>
    <p>Utilizamos medidas de seguridad estándar de la industria para proteger tu información contra acceso no autorizado.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Contacto</h4>
    <p>Si tienes preguntas sobre nuestra política de privacidad, puedes contactarnos en: <strong>contacto@terecazola.com</strong></p>
</div>
