<div class="politica-content">
    <h3 style="color: #4b0082; margin-bottom: 20px;">Filosofía de Tere Cazola</h3>
    <p>En Repostería Tere Cazola, creemos en la excelencia, la tradición y la pasión por la repostería fina.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Nuestra Misión</h4>
    <p>Ofrecemos productos de repostería de la más alta calidad, elaborados con ingredientes premium y recetas tradicionales que han sido perfeccionadas a lo largo de los años.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Nuestros Valores</h4>
    <ul>
        <li><strong>Calidad:</strong> Utilizamos solo los mejores ingredientes</li>
        <li><strong>Tradición:</strong> Respetamos las recetas clásicas</li>
        <li><strong>Innovación:</strong> Creamos nuevos sabores cada temporada</li>
        <li><strong>Compromiso:</strong> Nos dedicamos al cliente</li>
        <li><strong>Sostenibilidad:</strong> Cuidamos el medio ambiente</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Nuestro Proceso</h4>
    <p>Cada producto es elaborado artesanalmente con cuidado especial:</p>
    <ol>
        <li>Selección rigurosa de ingredientes</li>
        <li>Preparación con técnicas tradicionales</li>
        <li>Control de calidad en cada etapa</li>
        <li>Empaque cuidadoso para preservar frescura</li>
    </ol>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Compromiso Social</h4>
    <p>Creemos en apoyar a la comunidad local. Utilizamos proveedores locales siempre que es posible y contribuimos al desarrollo económico de Mérida.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">40 Años de Excelencia</h4>
    <p>Desde hace 40 años, Tere Cazola ha sido símbolo de calidad y tradición en la repostería yucateca. Tu confianza es nuestro mayor logro.</p>
</div>
