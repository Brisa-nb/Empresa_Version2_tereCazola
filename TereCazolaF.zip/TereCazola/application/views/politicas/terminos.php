<div class="politica-content">
    <h3 style="color: #4b0082; margin-bottom: 20px;">Términos y Condiciones</h3>
    <p>Al utilizar nuestro sitio web y realizar compras en Repostería Tere Cazola, aceptas los siguientes términos y condiciones.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Uso del Sitio Web</h4>
    <ul>
        <li>Debes tener al menos 18 años para realizar compras</li>
        <li>Eres responsable de mantener la confidencialidad de tu cuenta</li>
        <li>No se permite usar nuestro sitio para actividades ilícitas</li>
        <li>Respetamos todos los derechos de propiedad intelectual</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Productos y Precios</h4>
    <p>Los precios mostrados en nuestro sitio están sujetos a cambio sin previo aviso. Nos reservamos el derecho de:</p>
    <ul>
        <li>Cancelar un pedido si contiene errores de precio</li>
        <li>Limitar las cantidades de productos por cliente</li>
        <li>Rechazar pedidos sospechosos</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Responsabilidad</h4>
    <p>Repostería Tere Cazola no es responsable por:</p>
    <ul>
        <li>Daños causados por uso indebido del producto</li>
        <li>Cambios de opinión del cliente</li>
        <li>Reacciones alérgicas (consulta ingredientes antes de comprar)</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Modificaciones</h4>
    <p>Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios serán efectivos inmediatamente después de su publicación.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Ley Aplicable</h4>
    <p>Estos términos se rigen por las leyes de México.</p>
</div>
