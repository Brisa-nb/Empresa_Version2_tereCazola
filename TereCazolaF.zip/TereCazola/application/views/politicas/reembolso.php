<div class="politica-content">
    <h3 style="color: #4b0082; margin-bottom: 20px;">Política de Reembolso</h3>
    <p>En Repostería Tere Cazola, queremos que estés completamente satisfecho con tu compra. Si no lo estás, ofrecemos una política de reembolso clara y justa.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Período de Reembolso</h4>
    <p>Aceptamos reembolsos dentro de <strong>30 días</strong> desde la fecha de compra, siempre que el producto esté en condiciones originales.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Condiciones para Reembolso</h4>
    <ul>
        <li>El producto debe estar sin abrir o sin consumir</li>
        <li>Debe incluir el empaque original</li>
        <li>Debe incluir el recibo de compra o comprobante</li>
        <li>No se acepta reembolso por cambios de opinión sin causa justificada</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Proceso de Reembolso</h4>
    <ol>
        <li>Contacta al cliente con el producto y el recibo</li>
        <li>Inspeccionar el producto</li>
        <li>Procesar el reembolso en 5-7 días hábiles</li>
    </ol>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Productos Defectuosos</h4>
    <p>Si recibiste un producto defectuoso, podemos ofrecer un reemplazo o reembolso completo sin restricciones.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Contacto</h4>
    <p>Para solicitar un reembolso, envía un correo a: <strong>contacto@terecazola.com</strong></p>
</div>
