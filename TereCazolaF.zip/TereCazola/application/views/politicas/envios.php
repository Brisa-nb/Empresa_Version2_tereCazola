<div class="politica-content">
    <h3 style="color: #4b0082; margin-bottom: 20px;">Política de Envíos</h3>
    <p>En Repostería Tere Cazola, nos aseguran que tus pedidos lleguen frescos y en perfectas condiciones. Aquí te presentamos nuestra política de envíos.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Tiempos de Envío</h4>
    <ul>
        <li><strong>Mérida:</strong> Envío gratis, entrega en 24-48 horas</li>
        <li><strong>Yucatán:</strong> Envío $50, entrega en 3-5 días hábiles</li>
        <li><strong>Otros estados:</strong> Envío variable, entrega en 5-10 días hábiles</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Costo de Envío</h4>
    <p>El costo de envío se calcula según:</p>
    <ul>
        <li>Peso del producto</li>
        <li>Zona de entrega</li>
        <li>Método de envío seleccionado</li>
    </ul>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Empaque y Seguridad</h4>
    <p>Todos nuestros productos son empacados con cuidado especial para mantener su frescura y calidad. Utilizamos materiales aislantes para productos que lo requieren.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Seguimiento de Pedidos</h4>
    <p>Recibirás un código de seguimiento por correo electrónico para que puedas monitorear tu pedido en tiempo real.</p>
    
    <h4 style="color: #4b0082; margin-top: 20px;">Problemas con Envíos</h4>
    <p>Si tu producto llega dañado o perdido, contacta inmediatamente a: <strong>contacto@terecazola.com</strong> con fotos del daño.</p>
</div>
