<html class="js" lang="es" style="--viewport-height: 432px; --header-height: 70px; --announcement-bar-top: 28px; --announcement-bar-height: 28px; --transparent-header-menu-text-color: var(--color-link-text-inverse);"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <meta name="theme-color" content="">
    <link rel="canonical" href="https://terecazola.com/pages/menu">
    <link rel="preconnect" href="https://cdn.shopify.com" crossorigin=""><link rel="icon" type="image/png" href="//terecazola.com/cdn/shop/files/T-02_copia.png?crop=center&amp;height=32&amp;v=1698794861&amp;width=32"><link rel="preconnect" href="https://fonts.shopifycdn.com" crossorigin=""><title>
      menú

        – terecazola</title>

    

    

<meta property="og:site_name" content="terecazola">
<meta property="og:url" content="https://terecazola.com/pages/menu">
<meta property="og:title" content="menú">
<meta property="og:type" content="website">
<meta property="og:description" content="Creando dulzura desde 1985. ¡Deléitate con nuestra única y famosa Rosca Brioche!"><meta property="og:image" content="http://terecazola.com/cdn/shop/files/Terecazolal_ogo.jpg?v=1692975950">
  <meta property="og:image:secure_url" content="https://terecazola.com/cdn/shop/files/Terecazolal_ogo.jpg?v=1692975950">
  <meta property="og:image:width" content="609">
  <meta property="og:image:height" content="529"><meta name="twitter:site" content="@TereCazolaMX"><meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="menú">
<meta name="twitter:description" content="Creando dulzura desde 1985. ¡Deléitate con nuestra única y famosa Rosca Brioche!">


    <script type="text/javascript" async="" src="https://cdn.adtrace.ai/tiktok-track.js?shop=terecazola.myshopify.com"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/destination?id=MC-MMBCD60ZC5&amp;cx=c&amp;gtm=4e5bi1h1"></script><script src="https://connect.facebook.net/signals/config/264386886580412?v=2.9.243&amp;r=stable&amp;domain=terecazola.com&amp;hme=fdfab1132115f4ac7aabc9fd7eee63947594f6e6f1735b47a225dd71217525d3&amp;ex_m=89%2C147%2C127%2C18%2C65%2C66%2C120%2C61%2C41%2C121%2C70%2C60%2C134%2C78%2C13%2C88%2C26%2C115%2C108%2C68%2C71%2C114%2C131%2C97%2C136%2C7%2C3%2C4%2C6%2C5%2C2%2C79%2C87%2C137%2C214%2C158%2C55%2C216%2C217%2C48%2C173%2C25%2C67%2C222%2C221%2C161%2C28%2C54%2C8%2C57%2C83%2C84%2C85%2C90%2C111%2C27%2C24%2C113%2C110%2C109%2C128%2C69%2C130%2C129%2C43%2C53%2C105%2C12%2C133%2C38%2C203%2C205%2C168%2C21%2C22%2C23%2C15%2C16%2C37%2C33%2C35%2C34%2C74%2C80%2C82%2C95%2C119%2C122%2C39%2C96%2C19%2C17%2C101%2C62%2C31%2C124%2C123%2C125%2C116%2C20%2C30%2C52%2C94%2C132%2C63%2C14%2C126%2C29%2C183%2C154%2C275%2C201%2C145%2C186%2C179%2C155%2C92%2C112%2C73%2C103%2C47%2C40%2C102%2C107%2C51%2C58%2C42%2C98%2C46%2C49%2C45%2C86%2C135%2C0%2C106%2C11%2C104%2C9%2C1%2C50%2C81%2C56%2C59%2C100%2C77%2C76%2C44%2C117%2C75%2C72%2C64%2C99%2C91%2C36%2C118%2C32%2C93%2C10%2C138" async=""></script><script async="true" src="https://connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async="" src="//terecazola.com/cdn/s/trekkie.storefront.3c703df509f0f96f3237c9daa54e2777acf1a1dd.min.js"></script><script src="//terecazola.com/cdn/shop/t/5/assets/pubsub.js?v=47587058936531202851698777098" defer="defer"></script>
    <script src="//terecazola.com/cdn/shop/t/5/assets/global.js?v=91416107592059568341698777096" defer="defer"></script>

    <script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script><meta name="facebook-domain-verification" content="eivx07hfknfi6a1wufnqpb8rjth85w">
<meta name="google-site-verification" content="mH72pUYwCyEWmFjefWlhVa_elzjh9e6goytJhqSAN5U">
<meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/80698769709/digital_wallets/dialog">
<meta name="shopify-checkout-api-token" content="0819451831197a2516cf04c1df636dae">
<meta id="in-context-paypal-metadata" data-shop-id="80698769709" data-venmo-supported="false" data-environment="production" data-locale="es_ES" data-paypal-v4="true" data-currency="MXN">
<script async="async" src="/checkouts/internal/preloads.js?locale=es-MX"></script>
<script id="shopify-features" type="application/json">{"accessToken":"0819451831197a2516cf04c1df636dae","betas":["rich-media-storefront-analytics"],"domain":"terecazola.com","predictiveSearch":true,"shopId":80698769709,"locale":"es"}</script>
<script>var Shopify = Shopify || {};
Shopify.shop = "terecazola.myshopify.com";
Shopify.locale = "es";
Shopify.currency = {"active":"MXN","rate":"1.0"};
Shopify.country = "MX";
Shopify.theme = {"name":"Copia actualizada actualizada de Sahara","id":162649047341,"schema_name":"Sahara","schema_version":"1.1.8","theme_store_id":1926,"role":"main"};
Shopify.theme.handle = "null";
Shopify.theme.style = {"id":null,"handle":null};
Shopify.cdnHost = "terecazola.com/cdn";
Shopify.routes = Shopify.routes || {};
Shopify.routes.root = "/";</script>
<script type="module">!function(o){(o.Shopify=o.Shopify||{}).modules=!0}(window);</script>
<script>!function(o){function n(){var o=[];function n(){o.push(Array.prototype.slice.apply(arguments))}return n.q=o,n}var t=o.Shopify=o.Shopify||{};t.loadFeatures=n(),t.autoloadFeatures=n()}(window);</script>
<script id="shop-js-analytics" type="application/json">{"pageType":"page"}</script>
<script defer="defer" async="" type="module" src="//terecazola.com/cdn/shopifycloud/shop-js/modules/v2/client.init-shop-cart-sync_DaR8I8JV.es.esm.js"></script>
<script defer="defer" async="" type="module" src="//terecazola.com/cdn/shopifycloud/shop-js/modules/v2/chunk.common_CvUpgQgQ.esm.js"></script>
<script type="module">
  await import("//terecazola.com/cdn/shopifycloud/shop-js/modules/v2/client.init-shop-cart-sync_DaR8I8JV.es.esm.js");
await import("//terecazola.com/cdn/shopifycloud/shop-js/modules/v2/chunk.common_CvUpgQgQ.esm.js");

  window.Shopify.SignInWithShop?.initShopCartSync?.({"fedCMEnabled":true,"windoidEnabled":true});

</script>
<script>(function() {
  var isLoaded = false;
  function asyncLoad() {
    if (isLoaded) return;
    isLoaded = true;
    var urls = ["https:\/\/cdn.adtrace.ai\/tiktok-track.js?shop=terecazola.myshopify.com"];
    for (var i = 0; i < urls.length; i++) {
      var s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.src = urls[i];
      var x = document.getElementsByTagName('script')[0];
      x.parentNode.insertBefore(s, x);
    }
  };
  if(window.attachEvent) {
    window.attachEvent('onload', asyncLoad);
  } else {
    window.addEventListener('load', asyncLoad, false);
  }
})();</script>
<script id="__st">var __st={"a":80698769709,"offset":-18000,"reqid":"2ce20511-8a30-4838-8414-2477789971b3-1764193847","pageurl":"terecazola.com\/pages\/menu","s":"pages-129500447021","u":"1e3a0f901aa5","p":"page","rtyp":"page","rid":129500447021};</script>
<script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
<script id="captcha-bootstrap">!function(){'use strict';const t='contact',e='account',n='new_comment',o=[[t,t],['blogs',n],['comments',n],[t,'customer']],c=[[e,'customer_login'],[e,'guest_login'],[e,'recover_customer_password'],[e,'create_customer']],r=t=>t.map((([t,e])=>`form[action*='/${t}']:not([data-nocaptcha='true']) input[name='form_type'][value='${e}']`)).join(','),a=t=>()=>t?[...document.querySelectorAll(t)].map((t=>t.form)):[];function s(){const t=[...o],e=r(t);return a(e)}const i='password',u='form_key',d=['recaptcha-v3-token','g-recaptcha-response','h-captcha-response',i],f=()=>{try{return window.sessionStorage}catch{return}},m='__shopify_v',_=t=>t.elements[u];function p(t,e,n=!1){try{const o=window.sessionStorage,c=JSON.parse(o.getItem(e)),{data:r}=function(t){const{data:e,action:n}=t;return t[m]||n?{data:e,action:n}:{data:t,action:n}}(c);for(const[e,n]of Object.entries(r))t.elements[e]&&(t.elements[e].value=n);n&&o.removeItem(e)}catch(o){console.error('form repopulation failed',{error:o})}}const l='form_type',E='cptcha';function T(t){t.dataset[E]=!0}const w=window,h=w.document,L='Shopify',v='ce_forms',y='captcha';let A=!1;((t,e)=>{const n=(g='f06e6c50-85a8-45c8-87d0-21a2b65856fe',I='https://cdn.shopify.com/shopifycloud/storefront-forms-hcaptcha/ce_storefront_forms_captcha_hcaptcha.v1.5.2.iife.js',D={infoText:'Protegido por hCaptcha',privacyText:'Privacidad',termsText:'Términos'},(t,e,n)=>{const o=w[L][v],c=o.bindForm;if(c)return c(t,g,e,D).then(n);var r;o.q.push([[t,g,e,D],n]),r=I,A||(h.body.append(Object.assign(h.createElement('script'),{id:'captcha-provider',async:!0,src:r})),A=!0)});var g,I,D;w[L]=w[L]||{},w[L][v]=w[L][v]||{},w[L][v].q=[],w[L][y]=w[L][y]||{},w[L][y].protect=function(t,e){n(t,void 0,e),T(t)},Object.freeze(w[L][y]),function(t,e,n,w,h,L){const[v,y,A,g]=function(t,e,n){const i=e?o:[],u=t?c:[],d=[...i,...u],f=r(d),m=r(i),_=r(d.filter((([t,e])=>n.includes(e))));return[a(f),a(m),a(_),s()]}(w,h,L),I=t=>{const e=t.target;return e instanceof HTMLFormElement?e:e&&e.form},D=t=>v().includes(t);t.addEventListener('submit',(t=>{const e=I(t);if(!e)return;const n=D(e)&&!e.dataset.hcaptchaBound&&!e.dataset.recaptchaBound,o=_(e),c=g().includes(e)&&(!o||!o.value);(n||c)&&t.preventDefault(),c&&!n&&(function(t){try{if(!f())return;!function(t){const e=f();if(!e)return;const n=_(t);if(!n)return;const o=n.value;o&&e.removeItem(o)}(t);const e=Array.from(Array(32),(()=>Math.random().toString(36)[2])).join('');!function(t,e){_(t)||t.append(Object.assign(document.createElement('input'),{type:'hidden',name:u})),t.elements[u].value=e}(t,e),function(t,e){const n=f();if(!n)return;const o=[...t.querySelectorAll(`input[type='${i}']`)].map((({name:t})=>t)),c=[...d,...o],r={};for(const[a,s]of new FormData(t).entries())c.includes(a)||(r[a]=s);n.setItem(e,JSON.stringify({[m]:1,action:t.action,data:r}))}(t,e)}catch(e){console.error('failed to persist form',e)}}(e),e.submit())}));const S=(t,e)=>{t&&!t.dataset[E]&&(n(t,e.some((e=>e===t))),T(t))};for(const o of['focusin','change'])t.addEventListener(o,(t=>{const e=I(t);D(e)&&S(e,y())}));const B=e.get('form_key'),M=e.get(l),P=B&&M;t.addEventListener('DOMContentLoaded',(()=>{const t=y();if(P)for(const e of t)e.elements[l].value===M&&p(e,B);[...new Set([...A(),...v().filter((t=>'true'===t.dataset.shopifyCaptcha))])].forEach((e=>S(e,t)))}))}(h,new URLSearchParams(w.location.search),n,t,e,['guest_login'])})(!0,!0)}();</script>
<script integrity="sha256-52AcMU7V7pcBOXWImdc/TAGTFKeNjmkeM1Pvks/DTgc=" data-source-attribution="shopify.loadfeatures" defer="defer" src="//terecazola.com/cdn/shopifycloud/storefront/assets/storefront/load_feature-81c60534.js" crossorigin="anonymous"></script>
<script data-source-attribution="shopify.dynamic_checkout.dynamic.init">var Shopify=Shopify||{};Shopify.PaymentButton=Shopify.PaymentButton||{isStorefrontPortableWallets:!0,init:function(){window.Shopify.PaymentButton.init=function(){};var t=document.createElement("script");t.src="https://terecazola.com/cdn/shopifycloud/portable-wallets/latest/portable-wallets.es.js",t.type="module",document.head.appendChild(t)}};
</script>
<script data-source-attribution="shopify.dynamic_checkout.buyer_consent">
  function portableWalletsHideBuyerConsent(e){var t=document.getElementById("shopify-buyer-consent"),n=document.getElementById("shopify-subscription-policy-button");t&&n&&(t.classList.add("hidden"),t.setAttribute("aria-hidden","true"),n.removeEventListener("click",e))}function portableWalletsShowBuyerConsent(e){var t=document.getElementById("shopify-buyer-consent"),n=document.getElementById("shopify-subscription-policy-button");t&&n&&(t.classList.remove("hidden"),t.removeAttribute("aria-hidden"),n.addEventListener("click",e))}window.Shopify?.PaymentButton&&(window.Shopify.PaymentButton.hideBuyerConsent=portableWalletsHideBuyerConsent,window.Shopify.PaymentButton.showBuyerConsent=portableWalletsShowBuyerConsent);
</script>
<script data-source-attribution="shopify.dynamic_checkout.cart.bootstrap">document.addEventListener("DOMContentLoaded",(function(){function t(){return document.querySelector("shopify-accelerated-checkout-cart, shopify-accelerated-checkout")}if(t())Shopify.PaymentButton.init();else{new MutationObserver((function(e,n){t()&&(Shopify.PaymentButton.init(),n.disconnect())})).observe(document.body,{childList:!0,subtree:!0})}}));
</script>
<link id="shopify-accelerated-checkout-styles" rel="stylesheet" media="screen" href="https://terecazola.com/cdn/shopifycloud/portable-wallets/latest/accelerated-checkout-backwards-compat.css" crossorigin="anonymous">
<style id="shopify-accelerated-checkout-cart">
        #shopify-buyer-consent {
  margin-top: 1em;
  display: inline-block;
  width: 100%;
}

#shopify-buyer-consent.hidden {
  display: none;
}

#shopify-subscription-policy-button {
  background: none;
  border: none;
  padding: 0;
  text-decoration: underline;
  font-size: inherit;
  cursor: pointer;
}

#shopify-subscription-policy-button::before {
  box-shadow: none;
}

      </style>

<script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>
<style data-shopify="">

  @font-face {
  font-family: Figtree;
  font-weight: 300;
  font-style: normal;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_n3.e4cc0323f8b9feb279bf6ced9d868d88ce80289f.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_n3.db79ac3fb83d054d99bd79fccf8e8782b5cf449e.woff") format("woff");
}

  
  @font-face {
  font-family: Figtree;
  font-weight: 400;
  font-style: normal;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_n4.3c0838aba1701047e60be6a99a1b0a40ce9b8419.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_n4.c0575d1db21fc3821f17fd6617d3dee552312137.woff") format("woff");
}

  @font-face {
  font-family: Figtree;
  font-weight: 700;
  font-style: normal;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_n7.2fd9bfe01586148e644724096c9d75e8c7a90e55.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_n7.ea05de92d862f9594794ab281c4c3a67501ef5fc.woff") format("woff");
}

  @font-face {
  font-family: Figtree;
  font-weight: 300;
  font-style: italic;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_i3.914abbe7a583759f0a18bf02652c9ee1f4bb1c6d.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_i3.3d7354f07ddb3c61082efcb69896c65d6c00d9fa.woff") format("woff");
}

  @font-face {
  font-family: Figtree;
  font-weight: 700;
  font-style: italic;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_i7.06add7096a6f2ab742e09ec7e498115904eda1fe.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_i7.ee584b5fcaccdbb5518c0228158941f8df81b101.woff") format("woff");
}

  @font-face {
  font-family: Figtree;
  font-weight: 700;
  font-style: normal;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_n7.2fd9bfe01586148e644724096c9d75e8c7a90e55.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_n7.ea05de92d862f9594794ab281c4c3a67501ef5fc.woff") format("woff");
}

  @font-face {
  font-family: Figtree;
  font-weight: 400;
  font-style: normal;
  font-display: swap;
  src: url("//terecazola.com/cdn/fonts/figtree/figtree_n4.3c0838aba1701047e60be6a99a1b0a40ce9b8419.woff2") format("woff2"),
       url("//terecazola.com/cdn/fonts/figtree/figtree_n4.c0575d1db21fc3821f17fd6617d3dee552312137.woff") format("woff");
}


  :root {
    --font-body-family: Figtree, sans-serif;
    --font-body-style: normal;
    --font-body-weight: 300;

    --font-heading-family: Figtree, sans-serif;
    --font-heading-style: normal;
    --font-heading-weight: 700;

    --font-button-family: Figtree, sans-serif;
    --font-button-style: normal;
    --font-button-weight: 400;

    --font-heading-letter-spacing: 0;
    --font-heading-text-transform: uppercase;

    --font-body-scale: 0.8;
    --font-heading-scale: 1.2;

    --font-weight-normal: 400;
    --font-weight-bold: 700;
    --font-weight-light: ;

    --line-height-extra-small: 1;
    --line-height-small: 1.3;
    --line-height-medium: 1.6;

    --letter-spacing-extra-small: .05rem;
    --letter-spacing-small: .1rem;
    --letter-spacing-medium: .2rem;

    --font-size-extra-small: 1rem;
    --font-size-small: 1.2rem;
    --font-size-medium: 1.4rem;
    --font-size-large: 1.6rem;
    --font-size-extra-large: 1.8rem;

    --font-size-static-extra-small: 1rem;
    --font-size-static-small: 1.2rem;
    --font-size-static-medium: 1.4rem;
    --font-size-static-large: 1.6rem;
    --font-size-static-extra-large: 1.8rem;

    /* Typography */
    --color-heading-text: #510c76;
    --color-body-text: #5E5A59;

    /* Buttons and links */
    --color-button-outlined-text: #111111;
    --color-button-outlined-background: rgba(0,0,0,0);
    --color-button-filled-text: #FFFFFF;
    --color-button-filled-background: #510c76;

    --color-button-background: transparent;
    --color-button-outline: #FFFFFF;
    --color-button-text: #FFFFFF;

    --color-form-text: #111111;
    --color-form-button-text: #FFFFFF;

    --button-border-radius: 5rem;
    --button-text-transform: button--uppercase;
    --input-border-radius: 6rem;

    /* Other elements */
    --color-link: #333232;
    --color-link-text: #510c76;
    --color-default-link-text: #510c76;
    --color-tag-text: #111111;
    --color-tag-background: #FFFFFF;
    --color-border-elements: #E6E2E1;
    --color-cart-number-text: #510c76;
    --color-shipping-bar-progress: #ffc600;

    /* Backgrounds */
    --color-body-background: #FFFFFF;
    --color-image-background: #F5EBDF;
    --color-body-background-transparent-50: rgba(255, 255, 255, 0.5);
    --color-popup-background: #FFFFFF;

    /* Background Colors */
    --color-background-primary: #e3c1fd;
    --color-background-inverse: #FFFFFF;
    --color-background-light: #E6E2E1;
    --color-background-dark: #333232;
    --color-background-accent-1: #f1d9a1;
    --color-background-accent-2: #510c76;

    /* Text Colors */
    --color-text-primary: #510c76;
    --color-text-secondary: #5e5a59;
    --color-text-inverse: #ffffff;

    /* Text default */
    --color-heading-text-default: #510c76;
    --color-body-text-default: #5E5A59;

    --color-link-text-default: #510c76;
    --color-default-link-text-default: #510c76;

    /* Text secondary */
    --color-heading-text-secondary: #5e5a59;
    --color-body-text-secondary: #5e5a59;

    /* Text inverse */
    --color-heading-text-inverse: #ffffff;
    --color-body-text-inverse: #ffffff;

    --color-link-text-inverse: #ffffff;
    --color-default-link-text-inverse: #ffffff;

    /* Default section style */
    --color-default-background: #FFFFFF;
    --color-default-image-background: #F5EBDF;
    --color-default-border-elements: #E6E2E1;

    /* Secondary section style */
    --color-secondary-background: #5e5a59;
    --color-secondary-image-background: #f1d9a1;
    --color-secondary-border-elements: #E6E2E1;

    --color-button-hover-text: var(--color-button-text-inverse);
    --color-button-hover-outline: var(--color-button-outline);
    --color-button-hover-background: var(--color-button-outline);

    --color-success: #6BBD4F;
    --color-alert: #FAC151;
    --color-error: #D84339;
    --color-price-accent: #CD9B77;

    --color-white: #fff;
    --color-black: #111;
    --color-light: #ddd;

    --media-overlay-gradient-desktop: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.25) 100%);
    --media-overlay-gradient-mobile: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.25) 100%);

    --gradient-black: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.2) 100%);
    --gradient-overlay-horizontal: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2));
    --color-popup-overlay: rgba(0, 0, 0, 0.5);

    --page-width: 1440px;
    --page-width-md: 880px;
    --page-width-xs: 656px;
    --page-gutter: 2.4rem;

    --section-vertical-padding: 7.6rem;
    --section-vertical-padding-desktop: 9.6rem;

    --section-spacing-unit-desktop: 1.6rem;
    --section-spacing-unit-mobile:  1.2rem;

    --duration-short: 200ms;
    --duration-default: 300ms;
    --duration-long: 400ms;
    --duration-extra-long: 600ms;

    --z-header: 800;
    --z-modals: 900;
    --z-fab: 750;

    --header-top-position: calc(var(--header-height, 5.6rem) + var(--announcement-bar-height, 2.7rem));

    --card-media-padding: 0;
    --card-media-object-fit: contain;
    --card-media-background-color: #F5EBDF;

    --collection-sidebar-top: 0;

    --theme-js-animations-on-mobile: fade-in 800ms forwards paused;
  }

  

  @media screen and (min-width: 750px) {
    :root {
    --font-size-extra-small: 1.2rem;
    --font-size-small: 1.4rem;
    --font-size-medium: 1.6rem;
    --font-size-large: 1.8rem;
    --font-size-extra-large: 2rem;

    --page-gutter: 3.6rem;

    --section-vertical-padding: 8.6rem;

    --header-top-position: calc(var(--header-height, 7.4rem) + var(--announcement-bar-height, 3.5rem));
  }
}

  @media screen and (min-width: 990px) {
    :root {
  --page-gutter: 4rem;

  --section-vertical-padding: 9.6rem;
}
}

  @media screen and (min-width: 1100px) {
    :root {
--page-gutter: 5.6rem;
}
}</style><link href="//terecazola.com/cdn/shop/t/5/assets/base.css?v=145601782719245237361708698630" rel="stylesheet" type="text/css" media="all">
    <link rel="stylesheet" href="//terecazola.com/cdn/shop/t/5/assets/swiper-bundle.min.css?v=39633872178562917471698777095" media="all" onload="this.media='all'">
    <link rel="stylesheet" href="//terecazola.com/cdn/shop/t/5/assets/component-drawer.css?v=148830730825267654831698777094" media="all" onload="this.media='all'">
    <noscript>
      <link href="//terecazola.com/cdn/shop/t/5/assets/swiper-bundle.min.css?v=39633872178562917471698777095" rel="stylesheet" type="text/css" media="all" />
      <link href="//terecazola.com/cdn/shop/t/5/assets/component-drawer.css?v=148830730825267654831698777094" rel="stylesheet" type="text/css" media="all" />
    </noscript><link rel="stylesheet" href="//terecazola.com/cdn/shop/t/5/assets/component-predictive-search.css?v=167180920165480308801698777096" media="all" onload="this.media='all'">
      <script src="//terecazola.com/cdn/shop/t/5/assets/predictive-search.js?v=92622284360457197551698777097" defer="defer"></script>
      <noscript><link href="//terecazola.com/cdn/shop/t/5/assets/component-predictive-search.css?v=167180920165480308801698777096" rel="stylesheet" type="text/css" media="all" /></noscript><link rel="preload" as="font" href="//terecazola.com/cdn/fonts/figtree/figtree_n7.2fd9bfe01586148e644724096c9d75e8c7a90e55.woff2" type="font/woff2" crossorigin=""><link rel="preload" as="font" href="//terecazola.com/cdn/fonts/figtree/figtree_n3.e4cc0323f8b9feb279bf6ced9d868d88ce80289f.woff2" type="font/woff2" crossorigin=""><script>
      document.documentElement.className = document.documentElement.className.replace('no-js', 'js');

      if (Shopify.designMode) {
        document.documentElement.classList.add('shopify-design-mode');
      }
    </script>

    <script src="//terecazola.com/cdn/shop/t/5/assets/swiper-bundle.min.js?v=87330480114418983271698777096" defer="defer"></script>
    <script src="//terecazola.com/cdn/shop/t/5/assets/bodyScrollLock.min.js?v=54831410435734691211698777095" defer="defer"></script><style>
    @font-face {
  font-family: Radikal;
  src: url(https://cdn.shopify.com/s/files/1/0806/9876/9709/files/Nootype_-_Radikal.otf?v=1699367232);
}
    .header__inner{padding:10px 0 !important;}

    .cart-item__media a .media img {
    max-height: 140px;
      object-fit: contain;
}
    .store-locator__image-container span iframe{
        width: 100%;
    height: 100%;
          z-index: 9;
    position: relative;
  }
    .store-locator__form-container .store-locator__card-header__input{display:none;}
    .cart-item__media{
        max-height: 140px;
      
    }
   .cart-item__media .media {
    padding-top: calc(178 / 130 * 60%) !important;
}
   .accordion__body-inner .field--textarea{border:solid 1px #000;}

    .cart__summary-note .accordion__button{

          background-color: #510c76 !important;
    padding: 20px !important;
    text-align: center !important;
    border-radius: 15px !important;
    color: #fff !important;
      font-weight: 100 !important;
    }
    .cart__summary-actions{border-top:none !important;}
/*Precio del Item*/
    /*.card-product__price{display:none;}*/

    .shopify-policy__container{max-width: 800px;width:100%;padding-bottom:50px;text-align:justify;line-height: 30px;}

.before-and-after-grid-col-slider{
      max-width: 490px;
    margin-left: 84px;
}
.before-and-after-grid-col-text-content{
      width: 498px;
    text-align: justify;
padding-top:150px;
}    
    .section-before-and-after-title{
        font-size:25px !important;
      
      text-align:center;
    }
    .section-before-and-after-content{
        color: #5E5A59;
      max-width: 100%;
    padding: 25px 0;
    margin: 0 auto;
    font-weight: 400;
        font-size:13px !important;
    }
    @media(max-width:900px){
      .before-and-after-grid-col-slider{
      max-width: 100%;
    margin-left: 0;
}
.before-and-after-grid-col-text-content{
      width: 100%;
  
padding-top:0;
}    .ims-container {
    height: 45rem;
}
    }
  </style>


  
  <!-- BEGIN app block: shopify://apps/pixelpro-easy-pixel-install/blocks/turbo-tiktok/0f61e244-e2c9-43da-9523-9762c9f7e6bf -->









<script>
    window.__adTraceTikTokPaused = ``;
    window.__adTraceTikTokServerSideApiEnabled = ``;
    window.__adTraceShopifyDomain = `https://terecazola.com`;
    window.__adTraceIsProductPage = `page.menu-sucursales`.includes("product");
    window.__adTraceShopCurrency = `MXN`;
    window.__adTraceProductInfo = {
        "id": "",
        "name": ``,
        "price": "",
        "url": "",
        "description": null,
        "image": "<!-- Liquid error (shopify://apps/pixelpro-easy-pixel-install/blocks/turbo-tiktok/0f61e244-e2c9-43da-9523-9762c9f7e6bf line 31): invalid url input -->"
    };
    
</script>
<!-- END app block --><script src="https://cdn.shopify.com/extensions/05506e16-894f-4f03-a8b8-e0c1b0d28c3d/tiktok-pixel-for-adtrace-160/assets/tiktok-pixel.js" type="text/javascript" defer="defer"></script>
<link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
<script>(function(){if ("sendBeacon" in navigator && "performance" in window) {try {var session_token_from_headers = performance.getEntriesByType('navigation')[0].serverTiming.find(x => x.name == '_s').description;} catch {var session_token_from_headers = undefined;}var session_cookie_matches = document.cookie.match(/_shopify_s=([^;]*)/);var session_token_from_cookie = session_cookie_matches && session_cookie_matches.length === 2 ? session_cookie_matches[1] : "";var session_token = session_token_from_headers || session_token_from_cookie || "";function handle_abandonment_event(e) {var entries = performance.getEntries().filter(function(entry) {return /monorail-edge.shopifysvc.com/.test(entry.name);});if (!window.abandonment_tracked && entries.length === 0) {window.abandonment_tracked = true;var currentMs = Date.now();var navigation_start = performance.timing.navigationStart;var payload = {shop_id: 80698769709,url: window.location.href,navigation_start,duration: currentMs - navigation_start,session_token,page_type: "page"};window.navigator.sendBeacon("https://monorail-edge.shopifysvc.com/v1/produce", JSON.stringify({schema_id: "online_store_buyer_site_abandonment/1.1",payload: payload,metadata: {event_created_at_ms: currentMs,event_sent_at_ms: currentMs}}));}}window.addEventListener('pagehide', handle_abandonment_event);}}());</script>
<script id="web-pixels-manager-setup">(function e(e,d,r,n,o){if(void 0===o&&(o={}),!Boolean(null===(a=null===(i=window.Shopify)||void 0===i?void 0:i.analytics)||void 0===a?void 0:a.replayQueue)){var i,a;window.Shopify=window.Shopify||{};var t=window.Shopify;t.analytics=t.analytics||{};var s=t.analytics;s.replayQueue=[],s.publish=function(e,d,r){return s.replayQueue.push([e,d,r]),!0};try{self.performance.mark("wpm:start")}catch(e){}var l=function(){var e={modern:/Edge?\/(1{2}[4-9]|1[2-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Firefox\/(1{2}[4-9]|1[2-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Chrom(ium|e)\/(9{2}|\d{3,})\.\d+(\.\d+|)|(Maci|X1{2}).+ Version\/(15\.\d+|(1[6-9]|[2-9]\d|\d{3,})\.\d+)([,.]\d+|)( \(\w+\)|)( Mobile\/\w+|) Safari\/|Chrome.+OPR\/(9{2}|\d{3,})\.\d+\.\d+|(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS|CPU iPad OS)[ +]+(15[._]\d+|(1[6-9]|[2-9]\d|\d{3,})[._]\d+)([._]\d+|)|Android:?[ /-](13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})(\.\d+|)(\.\d+|)|Android.+Firefox\/(13[5-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+Chrom(ium|e)\/(13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|SamsungBrowser\/([2-9]\d|\d{3,})\.\d+/,legacy:/Edge?\/(1[6-9]|[2-9]\d|\d{3,})\.\d+(\.\d+|)|Firefox\/(5[4-9]|[6-9]\d|\d{3,})\.\d+(\.\d+|)|Chrom(ium|e)\/(5[1-9]|[6-9]\d|\d{3,})\.\d+(\.\d+|)([\d.]+$|.*Safari\/(?![\d.]+ Edge\/[\d.]+$))|(Maci|X1{2}).+ Version\/(10\.\d+|(1[1-9]|[2-9]\d|\d{3,})\.\d+)([,.]\d+|)( \(\w+\)|)( Mobile\/\w+|) Safari\/|Chrome.+OPR\/(3[89]|[4-9]\d|\d{3,})\.\d+\.\d+|(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS|CPU iPad OS)[ +]+(10[._]\d+|(1[1-9]|[2-9]\d|\d{3,})[._]\d+)([._]\d+|)|Android:?[ /-](13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})(\.\d+|)(\.\d+|)|Mobile Safari.+OPR\/([89]\d|\d{3,})\.\d+\.\d+|Android.+Firefox\/(13[5-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+Chrom(ium|e)\/(13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+(UC? ?Browser|UCWEB|U3)[ /]?(15\.([5-9]|\d{2,})|(1[6-9]|[2-9]\d|\d{3,})\.\d+)\.\d+|SamsungBrowser\/(5\.\d+|([6-9]|\d{2,})\.\d+)|Android.+MQ{2}Browser\/(14(\.(9|\d{2,})|)|(1[5-9]|[2-9]\d|\d{3,})(\.\d+|))(\.\d+|)|K[Aa][Ii]OS\/(3\.\d+|([4-9]|\d{2,})\.\d+)(\.\d+|)/},d=e.modern,r=e.legacy,n=navigator.userAgent;return n.match(d)?"modern":n.match(r)?"legacy":"unknown"}(),u="modern"===l?"modern":"legacy",c=(null!=n?n:{modern:"",legacy:""})[u],f=function(e){return[e.baseUrl,"/wpm","/b",e.hashVersion,"modern"===e.buildTarget?"m":"l",".js"].join("")}({baseUrl:d,hashVersion:r,buildTarget:u}),m=function(e){var d=e.version,r=e.bundleTarget,n=e.surface,o=e.pageUrl,i=e.monorailEndpoint;return{emit:function(e){var a=e.status,t=e.errorMsg,s=(new Date).getTime(),l=JSON.stringify({metadata:{event_sent_at_ms:s},events:[{schema_id:"web_pixels_manager_load/3.1",payload:{version:d,bundle_target:r,page_url:o,status:a,surface:n,error_msg:t},metadata:{event_created_at_ms:s}}]});if(!i)return console&&console.warn&&console.warn("[Web Pixels Manager] No Monorail endpoint provided, skipping logging."),!1;try{return self.navigator.sendBeacon.bind(self.navigator)(i,l)}catch(e){}var u=new XMLHttpRequest;try{return u.open("POST",i,!0),u.setRequestHeader("Content-Type","text/plain"),u.send(l),!0}catch(e){return console&&console.warn&&console.warn("[Web Pixels Manager] Got an unhandled error while logging to Monorail."),!1}}}}({version:r,bundleTarget:l,surface:e.surface,pageUrl:self.location.href,monorailEndpoint:e.monorailEndpoint});try{o.browserTarget=l,function(e){var d=e.src,r=e.async,n=void 0===r||r,o=e.onload,i=e.onerror,a=e.sri,t=e.scriptDataAttributes,s=void 0===t?{}:t,l=document.createElement("script"),u=document.querySelector("head"),c=document.querySelector("body");if(l.async=n,l.src=d,a&&(l.integrity=a,l.crossOrigin="anonymous"),s)for(var f in s)if(Object.prototype.hasOwnProperty.call(s,f))try{l.dataset[f]=s[f]}catch(e){}if(o&&l.addEventListener("load",o),i&&l.addEventListener("error",i),u)u.appendChild(l);else{if(!c)throw new Error("Did not find a head or body element to append the script");c.appendChild(l)}}({src:f,async:!0,onload:function(){if(!function(){var e,d;return Boolean(null===(d=null===(e=window.Shopify)||void 0===e?void 0:e.analytics)||void 0===d?void 0:d.initialized)}()){var d=window.webPixelsManager.init(e)||void 0;if(d){var r=window.Shopify.analytics;r.replayQueue.forEach((function(e){var r=e[0],n=e[1],o=e[2];d.publishCustomEvent(r,n,o)})),r.replayQueue=[],r.publish=d.publishCustomEvent,r.visitor=d.visitor,r.initialized=!0}}},onerror:function(){return m.emit({status:"failed",errorMsg:"".concat(f," has failed to load")})},sri:function(e){var d=/^sha384-[A-Za-z0-9+/=]+$/;return"string"==typeof e&&d.test(e)}(c)?c:"",scriptDataAttributes:o}),m.emit({status:"loading"})}catch(e){m.emit({status:"failed",errorMsg:(null==e?void 0:e.message)||"Unknown error"})}}})({shopId: 80698769709,storefrontBaseUrl: "https://terecazola.com",extensionsBaseUrl: "https://extensions.shopifycdn.com/cdn/shopifycloud/web-pixels-manager",monorailEndpoint: "https://monorail-edge.shopifysvc.com/unstable/produce_batch",surface: "storefront-renderer",enabledBetaFlags: ["2dca8a86"],webPixelsConfigList: [{"id":"807862573","configuration":"{\"config\":\"{\\\"pixel_id\\\":\\\"G-NTRS0FQ424\\\",\\\"target_country\\\":\\\"MX\\\",\\\"gtag_events\\\":[{\\\"type\\\":\\\"begin_checkout\\\",\\\"action_label\\\":\\\"G-NTRS0FQ424\\\"},{\\\"type\\\":\\\"search\\\",\\\"action_label\\\":\\\"G-NTRS0FQ424\\\"},{\\\"type\\\":\\\"view_item\\\",\\\"action_label\\\":[\\\"G-NTRS0FQ424\\\",\\\"MC-MMBCD60ZC5\\\"]},{\\\"type\\\":\\\"purchase\\\",\\\"action_label\\\":[\\\"G-NTRS0FQ424\\\",\\\"MC-MMBCD60ZC5\\\"]},{\\\"type\\\":\\\"page_view\\\",\\\"action_label\\\":[\\\"G-NTRS0FQ424\\\",\\\"MC-MMBCD60ZC5\\\"]},{\\\"type\\\":\\\"add_payment_info\\\",\\\"action_label\\\":\\\"G-NTRS0FQ424\\\"},{\\\"type\\\":\\\"add_to_cart\\\",\\\"action_label\\\":\\\"G-NTRS0FQ424\\\"}],\\\"enable_monitoring_mode\\\":false}\"}","eventPayloadVersion":"v1","runtimeContext":"OPEN","scriptVersion":"b2a88bafab3e21179ed38636efcd8a93","type":"APP","apiClientId":1780363,"privacyPurposes":[],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"]}},{"id":"665223469","configuration":"{\"pixelCode\":\"CPD4EU3C77UAD0EAGQF0\"}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"22e92c2ad45662f435e4801458fb78cc","type":"APP","apiClientId":4383523,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"]}},{"id":"387154221","configuration":"{\"pixel_id\":\"264386886580412\",\"pixel_type\":\"facebook_pixel\",\"metaapp_system_user_token\":\"-\"}","eventPayloadVersion":"v1","runtimeContext":"OPEN","scriptVersion":"ca16bc87fe92b6042fbaa3acc2fbdaa6","type":"APP","apiClientId":2329312,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"]}},{"id":"284426541","configuration":"{\"myshopifyDomain\":\"terecazola.myshopify.com\",\"fallbackTrackingEnabled\":\"0\",\"storeUsesCashOnDelivery\":\"false\"}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"14f12110be0eba0c1b16c0a6776a09e7","type":"APP","apiClientId":4503629,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_personal_data"]}},{"id":"shopify-app-pixel","configuration":"{}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"0450","apiClientId":"shopify-pixel","type":"APP","privacyPurposes":["ANALYTICS","MARKETING"]},{"id":"shopify-custom-pixel","eventPayloadVersion":"v1","runtimeContext":"LAX","scriptVersion":"0450","apiClientId":"shopify-pixel","type":"CUSTOM","privacyPurposes":["ANALYTICS","MARKETING"]}],isMerchantRequest: false,initData: {"shop":{"name":"terecazola","paymentSettings":{"currencyCode":"MXN"},"myshopifyDomain":"terecazola.myshopify.com","countryCode":"MX","storefrontUrl":"https:\/\/terecazola.com"},"customer":null,"cart":null,"checkout":null,"productVariants":[],"purchasingCompany":null},},"https://terecazola.com/cdn","ae1676cfwd2530674p4253c800m34e853cb",{"modern":"","legacy":""},{"shopId":"80698769709","storefrontBaseUrl":"https:\/\/terecazola.com","extensionBaseUrl":"https:\/\/extensions.shopifycdn.com\/cdn\/shopifycloud\/web-pixels-manager","surface":"storefront-renderer","enabledBetaFlags":"[\"2dca8a86\"]","isMerchantRequest":"false","hashVersion":"ae1676cfwd2530674p4253c800m34e853cb","publish":"custom","events":"[[\"page_viewed\",{}]]"});</script><script async="" src="https://terecazola.com/cdn/wpm/bae1676cfwd2530674p4253c800m34e853cbm.js" data-shop-id="80698769709" data-storefront-base-url="https://terecazola.com" data-extension-base-url="https://extensions.shopifycdn.com/cdn/shopifycloud/web-pixels-manager" data-surface="storefront-renderer" data-enabled-beta-flags="[&quot;2dca8a86&quot;]" data-is-merchant-request="false" data-hash-version="ae1676cfwd2530674p4253c800m34e853cb" data-publish="custom" data-events="[[&quot;page_viewed&quot;,{}]]" data-browser-target="modern"></script><script>
  window.ShopifyAnalytics = window.ShopifyAnalytics || {};
  window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
  window.ShopifyAnalytics.meta.currency = 'MXN';
  var meta = {"page":{"pageType":"page","resourceType":"page","resourceId":129500447021}};
  for (var attr in meta) {
    window.ShopifyAnalytics.meta[attr] = meta[attr];
  }
</script>
<script class="analytics">
  (function () {
    var customDocumentWrite = function(content) {
      var jquery = null;

      if (window.jQuery) {
        jquery = window.jQuery;
      } else if (window.Checkout && window.Checkout.$) {
        jquery = window.Checkout.$;
      }

      if (jquery) {
        jquery('body').append(content);
      }
    };

    var hasLoggedConversion = function(token) {
      if (token) {
        return document.cookie.indexOf('loggedConversion=' + token) !== -1;
      }
      return false;
    }

    var setCookieIfConversion = function(token) {
      if (token) {
        var twoMonthsFromNow = new Date(Date.now());
        twoMonthsFromNow.setMonth(twoMonthsFromNow.getMonth() + 2);

        document.cookie = 'loggedConversion=' + token + '; expires=' + twoMonthsFromNow;
      }
    }

    var trekkie = window.ShopifyAnalytics.lib = window.trekkie = window.trekkie || [];
    if (trekkie.integrations) {
      return;
    }
    trekkie.methods = [
      'identify',
      'page',
      'ready',
      'track',
      'trackForm',
      'trackLink'
    ];
    trekkie.factory = function(method) {
      return function() {
        var args = Array.prototype.slice.call(arguments);
        args.unshift(method);
        trekkie.push(args);
        return trekkie;
      };
    };
    for (var i = 0; i < trekkie.methods.length; i++) {
      var key = trekkie.methods[i];
      trekkie[key] = trekkie.factory(key);
    }
    trekkie.load = function(config) {
      trekkie.config = config || {};
      trekkie.config.initialDocumentCookie = document.cookie;
      var first = document.getElementsByTagName('script')[0];
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.onerror = function(e) {
        var scriptFallback = document.createElement('script');
        scriptFallback.type = 'text/javascript';
        scriptFallback.onerror = function(error) {
                var Monorail = {
      produce: function produce(monorailDomain, schemaId, payload) {
        var currentMs = new Date().getTime();
        var event = {
          schema_id: schemaId,
          payload: payload,
          metadata: {
            event_created_at_ms: currentMs,
            event_sent_at_ms: currentMs
          }
        };
        return Monorail.sendRequest("https://" + monorailDomain + "/v1/produce", JSON.stringify(event));
      },
      sendRequest: function sendRequest(endpointUrl, payload) {
        // Try the sendBeacon API
        if (window && window.navigator && typeof window.navigator.sendBeacon === 'function' && typeof window.Blob === 'function' && !Monorail.isIos12()) {
          var blobData = new window.Blob([payload], {
            type: 'text/plain'
          });

          if (window.navigator.sendBeacon(endpointUrl, blobData)) {
            return true;
          } // sendBeacon was not successful

        } // XHR beacon

        var xhr = new XMLHttpRequest();

        try {
          xhr.open('POST', endpointUrl);
          xhr.setRequestHeader('Content-Type', 'text/plain');
          xhr.send(payload);
        } catch (e) {
          console.log(e);
        }

        return false;
      },
      isIos12: function isIos12() {
        return window.navigator.userAgent.lastIndexOf('iPhone; CPU iPhone OS 12_') !== -1 || window.navigator.userAgent.lastIndexOf('iPad; CPU OS 12_') !== -1;
      }
    };
    Monorail.produce('monorail-edge.shopifysvc.com',
      'trekkie_storefront_load_errors/1.1',
      {shop_id: 80698769709,
      theme_id: 162649047341,
      app_name: "storefront",
      context_url: window.location.href,
      source_url: "//terecazola.com/cdn/s/trekkie.storefront.3c703df509f0f96f3237c9daa54e2777acf1a1dd.min.js"});

        };
        scriptFallback.async = true;
        scriptFallback.src = '//terecazola.com/cdn/s/trekkie.storefront.3c703df509f0f96f3237c9daa54e2777acf1a1dd.min.js';
        first.parentNode.insertBefore(scriptFallback, first);
      };
      script.async = true;
      script.src = '//terecazola.com/cdn/s/trekkie.storefront.3c703df509f0f96f3237c9daa54e2777acf1a1dd.min.js';
      first.parentNode.insertBefore(script, first);
    };
    trekkie.load(
      {"Trekkie":{"appName":"storefront","development":false,"defaultAttributes":{"shopId":80698769709,"isMerchantRequest":null,"themeId":162649047341,"themeCityHash":"17409456403041192567","contentLanguage":"es","currency":"MXN","eventMetadataId":"c2373eae-9ee9-4f76-89d3-77d378f4b936"},"isServerSideCookieWritingEnabled":true,"monorailRegion":"shop_domain","enabledBetaFlags":["f0df213a"]},"Session Attribution":{},"S2S":{"facebookCapiEnabled":true,"source":"trekkie-storefront-renderer","apiClientId":580111}}
    );

    var loaded = false;
    trekkie.ready(function() {
      if (loaded) return;
      loaded = true;

      window.ShopifyAnalytics.lib = window.trekkie;

      var originalDocumentWrite = document.write;
      document.write = customDocumentWrite;
      try { window.ShopifyAnalytics.merchantGoogleAnalytics.call(this); } catch(error) {};
      document.write = originalDocumentWrite;

      window.ShopifyAnalytics.lib.page(null,{"pageType":"page","resourceType":"page","resourceId":129500447021,"shopifyEmitted":true});

      var match = window.location.pathname.match(/checkouts\/(.+)\/(thank_you|post_purchase)/)
      var token = match? match[1]: undefined;
      if (!hasLoggedConversion(token)) {
        setCookieIfConversion(token);
        
      }
    });


        var eventsListenerScript = document.createElement('script');
        eventsListenerScript.async = true;
        eventsListenerScript.src = "//terecazola.com/cdn/shopifycloud/storefront/assets/shop_events_listener-3da45d37.js";
        document.getElementsByTagName('head')[0].appendChild(eventsListenerScript);

})();</script><script async="" src="//terecazola.com/cdn/shopifycloud/storefront/assets/shop_events_listener-3da45d37.js"></script>
<script defer="" src="https://terecazola.com/cdn/shopifycloud/perf-kit/shopify-perf-kit-2.1.2.min.js" data-application="storefront-renderer" data-shop-id="80698769709" data-render-region="gcp-us-east1" data-page-type="page" data-theme-instance-id="162649047341" data-theme-name="Sahara" data-theme-version="1.1.8" data-monorail-region="shop_domain" data-resource-timing-sampling-rate="10" data-shs="true" data-shs-beacon="true" data-shs-export-with-fetch="true" data-shs-logs-sample-rate="1"></script>
<script src="https://terecazola.com/web-pixels@ae1676cfwd2530674p4253c800m34e853cb/app/web-pixel-807862573@b2a88bafab3e21179ed38636efcd8a93/pixel.modern.js" async="" data-pixel-id="807862573" data-pixel-type="APP"></script><script src="https://terecazola.com/web-pixels@ae1676cfwd2530674p4253c800m34e853cb/app/web-pixel-387154221@ca16bc87fe92b6042fbaa3acc2fbdaa6/pixel.modern.js" async="" data-pixel-id="387154221" data-pixel-type="APP"></script><script type="module" defer="" src="https://terecazola.com/cdn/shopifycloud/consent-tracking-api/v0.1/consent-tracking-api.js"></script><style data-description="gravity-font-faces">
@font-face {
  font-family: 'GTStandard-M';
  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MRegular.woff2')
    format('woff2');
  font-style: normal;
  font-weight: 450;
  font-display: swap;
}

@font-face {
  font-family: 'GTStandard-M';
  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MMedium.woff2')
    format('woff2');
  font-style: normal;
  font-weight: 500;
  font-display: swap;
}

@font-face {
  font-family: 'GTStandard-M';
  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MSemibold.woff2')
    format('woff2');
  font-style: normal;
  font-weight: 600;
  font-display: swap;
}</style><link rel="dns-prefetch preconnect" href="https://cdn.shopify.com" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/polyfills.Ba0kryUm.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/app.BLArQDYv.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/locale-es.BUvBVtYO.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage.CoBnjGd8.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/LocalizationExtensionField.D5nf2z1H.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText.1nNNmo0r.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/ShopPayOptInDisclaimer.BfnDmL6R.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons.OFe690M_.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/StockProblemsLineItemList.ChAiPLLo.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/DeliveryMethodSelectorSection.x-XTbwH-.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/useEditorShopPayNavigation.-ELK4PNN.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment.B5q5rI4Q.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/SeparatePaymentsNotice.CeyXWaun.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown.DmWG3DTh.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal.D4kvkWHk.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview.D08SRaqf.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/component-ShopPayVerificationSwitch.AGvlt7bE.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/useSubscribeMessenger.CquQKfwG.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/index.DReDgNMq.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="script" href="/cdn/shopifycloud/checkout-web/assets/c1/PayButtonSection.BIXN04gI.js" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/app.Du6SSCMk.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.Dx_lrSVd.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/DeliveryMethodSelectorSection.BvrdqG-K.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/ShopPayVerificationSwitch.WW3cs_z5.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/useEditorShopPayNavigation.CBpWLJzT.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/VaultedPayment.OxMVm7u-.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="style" href="/cdn/shopifycloud/checkout-web/assets/c1/assets/StackedMerchandisePreview.CKAakmU8.css" crossorigin=""><link rel="prefetch" fetchpriority="low" as="image" href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/logo-terecazola_x320.png?v=1693340079" crossorigin=""></head>

  <body class="template template--page template--menu-sucursales template-theme--sahara">
    <div tabindex="-1" aria-hidden="true" id="web-pixels-manager-sandbox-container" data-shopify-privacy="exclude" style="height: 0px !important; width: 0px !important; position: fixed !important; visibility: hidden !important; overflow: hidden !important; z-index: -100 !important; margin: 0px !important; padding: 0px !important; border: 0px !important;"><iframe tabindex="-1" aria-hidden="true" name="web-pixel-sandbox-CUSTOM-shopify-custom-pixel-LAX-ae1676cfwd2530674p4253c800m34e853cb" src="https://terecazola.com/web-pixels@ae1676cfwd2530674p4253c800m34e853cb/custom/web-pixel-shopify-custom-pixel@0450/sandbox/modern/pages/menu" id="web-pixel-sandbox-CUSTOM-shopify-custom-pixel-LAX-ae1676cfwd2530674p4253c800m34e853cb" sandbox="allow-scripts allow-forms" style="height: 0px !important; width: 0px !important; visibility: hidden !important;"></iframe></div><a class="skip-to-content-link button visually-hidden" href="#MainContent">Ir al contenido</a><div id="shopify-section-cookie-banner" class="shopify-section"><link href="//terecazola.com/cdn/shop/t/5/assets/section-cookie-banner.css?v=28186666874704091791698777096" rel="stylesheet" type="text/css" media="all">
  <script src="//terecazola.com/cdn/shop/t/5/assets/cookie-banner.js?v=44863611379243583801698777095" defer="defer"></script>

  <cookie-banner class="no-js-hidden js-animation-fade-in text-colors-default background-colors-accent-1 animation-init animation-none">
    <div class="cookie-banner__text">
      <p>Este sitio web utiliza cookies para mejorar su experiencia. Asumiremos que está de acuerdo con esto, pero puede optar por no participar si lo desea.</p>
    </div><!-- /.cookie-banner__text -->

    <div class="cookie-banner__actions">
      <ul class="list-unstyled"><li>
            <a href="#" class="link cookie-banner__link">Leer más</a>
          </li><li>
          <button type="button" class="link cookie-banner__link" id="accept-cookies" name="accept-cookies" data-action="">Aceptar</button>
        </li>
      </ul><!-- /.list-unstyled -->
    </div><!-- /.cookie-banner__actions -->
  </cookie-banner>
</div><div id="shopify-section-newsletter-popup" class="shopify-section"><link href="//terecazola.com/cdn/shop/t/5/assets/section-newsletter-popup.css?v=3636825494677007671698777095" rel="stylesheet" type="text/css" media="all">

    <script src="//terecazola.com/cdn/shop/t/5/assets/cookies.js?v=121601133523406246751698777096" defer="defer"></script>
    <script src="//terecazola.com/cdn/shop/t/5/assets/newsletter-popup.js?v=52388643459782696391698777095" defer="defer"></script>

    <newsletter-popup id="NewsletterModal-newsletter-popup" class="newsletter-popup" data-delay="4">
      <div class="newsletter-popup__wrapper color-body-background text-colors-default background-colors-default" aria-modal="true" role="dialog" aria-labelledby="Newsletter Modal" tabindex="-1"><div class="newsletter-popup__content"><h6 class="newsletter-popup__title h2">ATENCIÓN</h6><!-- /.newsletter-popup__title --><div class="newsletter-popup__entry">Nuestra tienda en línea está diseñada exclusivamente para envíos nacionales a ciudades donde no contamos con sucursales. Si en tu ciudad hay una sucursal, te invitamos a visitarnos. Para conocer el menú disponible en tu localidad, visita el apartado 'Menú' y selecciona tu ciudad.</div><!-- /.newsletter-popup__entry --><div class="newsletter-popup__form"><form method="post" action="/contact#contact-form-newsletter-popup" id="contact-form-newsletter-popup" accept-charset="UTF-8" class="newsletter-form js-form"><input type="hidden" name="form_type" value="customer"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="contact[tags]" value="newsletter">

  <div class="newsletter__controls">
<div class="field newsletter__field" data-input-wrapper=""><label for="NewsletterForm--newsletter-popup" class="field__label visually-hidden">Correo electrónico</label><input type="email" id="NewsletterForm--newsletter-popup" name="contact[email]" placeholder="Ingresa tu correo electrónico" required="" pattern="^[\w]{1,}[\w.+-]{0,}@[\w-]{2,}([.][a-zA-Z]{2,}|[.][\w-]{2,}[.][a-zA-Z]{2,})$" aria-required="true" autocapitalize="off" autocomplete="email" class="field__input">

  <span class="field__message hidden" data-message=""></span></div><!-- /.field -->
<button type="submit" class="button-reset newsletter__button" id="Subscribe-newsletter-popup" name="commit">Suscribirse</button>
  </div><!-- /.newsletter__controls --></form></div><!-- /.newsletter-popup__form -->

          <button id="ModalClose-newsletter-popup" type="button" class="link">CERRAR</button>
        </div><!-- /.newsletter-popup__content -->
      </div><!-- /.newsletter-popup__wrapper -->
    </newsletter-popup>
</div><div id="shopify-section-age-verification-popup" class="shopify-section">
</div><!-- BEGIN sections: header-group -->
<!-- END sections: header-group -->
<br>
<br>
<br>
<br>
<br>
 <title>Tienda en Línea</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
<div style="text-align:center;">
<?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {

        // Barra morada sin texto
        echo '<div style="
            width:100%;
            background:rgba(75,0,130,0.7);
            height:70px;
            margin-top:90px;
            position:relative;
            z-index:2;
        "></div>';

        // Contenido del PA (ej: "CONTÁCTATE CON NOSOTROS")
        echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' 
                . html_entity_decode($item->contenido) . 
             '</div>';
    }
} else {
    echo "No hay datos";
}
?>
<section id="shopify-section-cart-drawer" class="shopify-section"><link href="//terecazola.com/cdn/shop/t/5/assets/component-cart-drawer.css?v=51279764607127487051706622101" rel="stylesheet" type="text/css" media="all"><link rel="stylesheet" href="//terecazola.com/cdn/shop/t/5/assets/component-cart.css?v=26978659163481519921698777098" media="all" onload="this.media='all'">
<link rel="stylesheet" href="//terecazola.com/cdn/shop/t/5/assets/component-cart-items.css?v=98224882210996028381698777098" media="all" onload="this.media='all'">
<link rel="stylesheet" href="//terecazola.com/cdn/shop/t/5/assets/component-cart-recommendations.css?v=107872643708805746261698777095" media="all" onload="this.media='all'">

<noscript><link href="//terecazola.com/cdn/shop/t/5/assets/component-cart.css?v=26978659163481519921698777098" rel="stylesheet" type="text/css" media="all" /><link href="//terecazola.com/cdn/shop/t/5/assets/component-cart-items.css?v=98224882210996028381698777098" rel="stylesheet" type="text/css" media="all" /><link href="//terecazola.com/cdn/shop/t/5/assets/component-cart-recommendations.css?v=107872643708805746261698777095" rel="stylesheet" type="text/css" media="all" /></noscript>

<script src="//terecazola.com/cdn/shop/t/5/assets/cart.js?v=123971176106246832391698777096" defer="defer"></script>
<script src="//terecazola.com/cdn/shop/t/5/assets/cart-drawer.js?v=81464427569435135971698777097" defer="defer"></script>
<script src="//terecazola.com/cdn/shop/t/5/assets/cart-recommendations.js?v=60920287679697510641698777098" defer="defer"></script>
<style> #shopify-section-template--21517467910445__b5bcb474-0bbf-4419-bdd2-b3155bfcb9d2 .container {max-width: 800px;} @media (max-width: 800px) {#shopify-section-template--21517467910445__b5bcb474-0bbf-4419-bdd2-b3155bfcb9d2 .container p {text-align: justify !important; }} </style></div><div id="shopify-section-template--21517467910445__d1f12f06-87ee-4b9d-9db5-cf79d97cf95a" class="shopify-section"><link href="//terecazola.com/cdn/shop/t/5/assets/section-trust-indicators.css?v=87274242436892505931698777096" rel="stylesheet" type="text/css" media="all">

  <section class="section-trust-indicators pt-0-desktop pb-0-desktop
    pt-0-mobile pb-0-mobile
    section-trust-indicators--layout-1
    section-trust-indicators--3">
    <div class="container"><div class="section-trust-indicators__inner">
          <div class="section-trust-indicators__tile js-animation-fade-in text-colors-default background-colors-default animation-init animation-none">
        <div class="section-trust-indicators__content"><span class="section-trust-indicators__decorator text-colors-default background-colors-accent-2">
                <img src="//terecazola.com/cdn/shop/files/brioche-01.svg?v=1698948912&amp;width=24" alt="MÉRIDA" srcset="//terecazola.com/cdn/shop/files/brioche-01.svg?v=1698948912&amp;width=24 24w" width="24" height="16" loading="lazy">
              
</span><h3 class="section-trust-indicators__title">MÉRIDA</h3>
            <!-- /.section-trust-indicators__title --><a href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/CATALOGO_TERE_CAZOLA_MERIDA2.pdf?v=1763134672" class="section-trust-indicators__link link">MENÚ</a></div>
        <!-- /.section-trust-indicators__content -->
      </div>
      <!-- /.section-trust-indicators__tile --><div class="section-trust-indicators__tile js-animation-fade-in text-colors-default background-colors-default animation-init animation-none">
        <div class="section-trust-indicators__content"><span class="section-trust-indicators__decorator text-colors-default background-colors-accent-2">
                <img src="//terecazola.com/cdn/shop/files/cheese.svg?v=1698948938&amp;width=24" alt="CDMX" srcset="//terecazola.com/cdn/shop/files/cheese.svg?v=1698948938&amp;width=24 24w" width="24" height="19" loading="lazy">
              
</span><h3 class="section-trust-indicators__title">CDMX</h3>
            <!-- /.section-trust-indicators__title --><a href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/CATALOGO_TERE_CAZOLA_CDMX.pdf?v=1763134672" class="section-trust-indicators__link link">MENÚ</a></div>
        <!-- /.section-trust-indicators__content -->
      </div>
      <!-- /.section-trust-indicators__tile --><div class="section-trust-indicators__tile js-animation-fade-in text-colors-default background-colors-default animation-init animation-none">
        <div class="section-trust-indicators__content"><span class="section-trust-indicators__decorator text-colors-default background-colors-accent-2">
                <img src="//terecazola.com/cdn/shop/files/orejas.svg?v=1698948985&amp;width=24" alt="VILLAHERMOSA" srcset="//terecazola.com/cdn/shop/files/orejas.svg?v=1698948985&amp;width=24 24w" width="24" height="16" loading="lazy">
              
</span><h3 class="section-trust-indicators__title">VILLAHERMOSA</h3>
            <!-- /.section-trust-indicators__title --><a href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/CATALOGO_TERE_CAZOLA_VILLAHERMOSA.pdf?v=1763481537" class="section-trust-indicators__link link">MENÚ</a></div>
        <!-- /.section-trust-indicators__content -->
      </div>
      <!-- /.section-trust-indicators__tile -->
        </div><!-- /.section-trust-indicators__inner --></div><!-- /.container -->
  </section><!-- /.section-trust-indicators -->
</div><div id="shopify-section-template--21517467910445__ff7767f7-1853-41e6-84f7-42cc094506b8" class="shopify-section"><link href="//terecazola.com/cdn/shop/t/5/assets/section-trust-indicators.css?v=87274242436892505931698777096" rel="stylesheet" type="text/css" media="all">

  <section class="section-trust-indicators pt-0-desktop pb-0-desktop
    pt-0-mobile pb-0-mobile
    section-trust-indicators--layout-1
    section-trust-indicators--3">
    <div class="container"><div class="section-trust-indicators__inner">
          <div class="section-trust-indicators__tile js-animation-fade-in text-colors-default background-colors-default animation-init animation-none">
        <div class="section-trust-indicators__content"><span class="section-trust-indicators__decorator text-colors-default background-colors-accent-2">
                <img src="//terecazola.com/cdn/shop/files/hojaldras.svg?v=1698949008&amp;width=24" alt="CD. DEL CARMEN" srcset="//terecazola.com/cdn/shop/files/hojaldras.svg?v=1698949008&amp;width=24 24w" width="24" height="19" loading="lazy">
              
</span><h3 class="section-trust-indicators__title">CD. DEL CARMEN</h3>
            <!-- /.section-trust-indicators__title --><a href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/CATALOGO_TERE_CAZOLA_CD_DEL_CARMEN.pdf?v=1763150036" class="section-trust-indicators__link link">MENÚ</a></div>
        <!-- /.section-trust-indicators__content -->
      </div>
      <!-- /.section-trust-indicators__tile --><div class="section-trust-indicators__tile js-animation-fade-in text-colors-default background-colors-default animation-init animation-none">
        <div class="section-trust-indicators__content"><span class="section-trust-indicators__decorator text-colors-default background-colors-accent-2">
                <img src="//terecazola.com/cdn/shop/files/brownies-06.svg?v=1698949304&amp;width=24" alt="CAMPECHE" srcset="//terecazola.com/cdn/shop/files/brownies-06.svg?v=1698949304&amp;width=24 24w" width="24" height="15" loading="lazy">
              
</span><h3 class="section-trust-indicators__title">CAMPECHE</h3>
            <!-- /.section-trust-indicators__title --><a href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/CATALOGO_TERE_CAZOLA_CAMPECHE.pdf?v=1763150037" class="section-trust-indicators__link link">MENÚ</a></div>
        <!-- /.section-trust-indicators__content -->
      </div>
      <!-- /.section-trust-indicators__tile --><div class="section-trust-indicators__tile js-animation-fade-in text-colors-default background-colors-default animation-init animation-none">
        <div class="section-trust-indicators__content"><span class="section-trust-indicators__decorator text-colors-default background-colors-accent-2">
                <img src="//terecazola.com/cdn/shop/files/bolitas.svg?v=1698949052&amp;width=24" alt="QUINTANA ROO" srcset="//terecazola.com/cdn/shop/files/bolitas.svg?v=1698949052&amp;width=24 24w" width="24" height="18" loading="lazy">
              
</span><h3 class="section-trust-indicators__title">QUINTANA ROO</h3>
            <!-- /.section-trust-indicators__title --><a href="https://cdn.shopify.com/s/files/1/0806/9876/9709/files/CARPETA_CATALOGO_TERE_CAZOLA_QUINTANA_ROO.pdf?v=1763150036" class="section-trust-indicators__link link">MENÚ</a></div>
        <!-- /.section-trust-indicators__content -->
      </div>
      <!-- /.section-trust-indicators__tile -->
        </div><!-- /.section-trust-indicators__inner --></div><!-- /.container -->
  </section><!-- /.section-trust-indicators -->
</div>
    </main>

    <!-- BEGIN sections: footer-group -->