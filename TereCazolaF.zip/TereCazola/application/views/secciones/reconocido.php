<div class="sellos-wrapper">
  <div class="sellos-row">
    <div class="sello-item">
      <img src="assets/imagenes/sello1.png" alt="Sello 1">
    </div>
    <div class="sello-item">
      <img src="assets/imagenes/sello2.png" alt="Sello 2">
    </div>
    <div class="sello-item">
      <img src="assets/imagenes/sello3.png" alt="Sello 3">
    </div>
  </div>
</div>

<style>
/* Contenedor general */
.sellos-wrapper {
  width: 100%;
  padding: 20px 15px; /* espacio alrededor */
  box-sizing: border-box;
}

/* Fila flex que contiene las 3 imágenes */
.sellos-row {
  display: flex;
  gap: 16px; /* espacio entre sellos */
  align-items: stretch;
  justify-content: center; /* centrar si hay espacio extra */
}

/* Cada item ocupa igual espacio */
.sello-item {
  flex: 1 1 0;       /* crecer/encoger por igual */
  max-width: 33.333%;/* máximo un tercio del ancho en pantallas grandes */
  box-sizing: border-box;
}

/* Imagen: responsiva y cubriendo su caja (sin estirar) */
.sello-item img {
  width: 100%;
  height: auto;         /* mantiene proporción natural */
  display: block;
  object-fit: contain;  /* usa 'cover' si prefieres recortar para igualar altura */
  border-radius: 6px;   /* opcional: bordes suaves */
}

/* --- Responsive: apilar verticalmente en pantallas pequeñas --- */
@media (max-width: 768px) {
  .sellos-row {
    flex-direction: column;
    gap: 12px;
  }
  .sello-item {
    max-width: 350px; /* tamaño cuando están en vertical */
    margin: 0 auto;
  }
}
</style>