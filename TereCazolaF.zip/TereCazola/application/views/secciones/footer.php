<footer class="footer">
    <div class="container">

        <div class="row footer-sections">

            <div class="col-sm-4 footer-column">
                <h5 class="footer-heading">PÓLITICAS</h5>
                <ul class="footer-list">
                    <li><a href="#" onclick="cargarPolitica('privacidad')" style="color: #6f3fa8; cursor: pointer;">PRIVACIDAD</a></li>
                    <li><a href="#" onclick="cargarPolitica('reembolso')" style="color: #6f3fa8; cursor: pointer;">REEMBOLSO</a></li>
                    <li><a href="#" onclick="cargarPolitica('envios')" style="color: #6f3fa8; cursor: pointer;">ENVÍO</a></li>
                    <li><a href="#" onclick="cargarPolitica('terminos')" style="color: #6f3fa8; cursor: pointer;">TÉRMINOS</a></li>
                    <li><a href="#" onclick="cargarPolitica('filosofia')" style="color: #6f3fa8; cursor: pointer;">FILOSOFÍA</a></li>
                </ul>
            </div>

            <div class="col-sm-4 footer-column">
                <h5 class="footer-heading">MENÚ PRINCIPAL</h5>
                <ul class="footer-list">
                    <li><a href="<?=base_url('inicio')?>">INICIO</a></li>
                    <li><a href="<?=base_url('tiendal')?>">TIENDA EN LÍNEA</a></li>
                    <li><a href="<?=base_url('menu')?>">MENÚ</a></li>
                    <li><a href="<?=base_url('sucursales')?>">SUCURSALES</a></li>
                    <li><a href="<?=base_url('conocenos')?>">CONÓCENOS</a></li>
                    <li><a href="<?=base_url('contacto')?>">CONTÁCTO</a></li>
                </ul>
                </div>

                <div class="col-sm-4 footer-column">
                     <h5 class="footer-heading">NUESTRAS REDES</h5>
                     <ul class="footer-list">
                        <a href="https://www.facebook.com/terecazolamx" target="_blank" class="social-icon">
                            <i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i>
                        </a>

                        <a href="https://www.instagram.com/terecazolamx/" target="_blank" class="social-icon">
                            <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                        </a>

                        <a href="https://x.com/TereCazolaMX" target="_blank" class="social-icon">
                            <i class="fa fa-twitter fa-3x" aria-hidden="true"></i>
                        </a>

                        <a href="https://www.linkedin.com/company/tere-cazola-reposteria-fina/" target="_blank" class="social-icon">
                             <i class="fa fa-linkedin fa-3x" aria-hidden="true"></i>
                        </a>

                        <a href="https://www.youtube.com/@TereCazolamx" target="_blank" class="social-icon">
                            <i class="fa fa-youtube-play fa-3x" aria-hidden="true"></i>
                        </a>

                    </ul>
                </div>
        <div style="text-align:center; margin-top:25px;">
             <h4 style="color:#4b0082; font-weight:bold;">PÍDENOS TAMBIÉN EN</h4>

                <div style="display:flex; justify-content:center; gap:25px; margin-top:10px; font-size:48px;">
                    <!-- Uber Eats -->
                    <a href="https://www.ubereats.com" target="_blank">
                        <img src="<?=base_url('assets/imagenes/uber.png')?>"
                        style="width:55px; height:55px;" alt="Uber Eats">
                    </a>

                    <!-- DiDi Food -->
                    <a href="https://www.didi-food.com" target="_blank">
                        <img src="<?=base_url('assets/imagenes/didifood.png')?>"
                        style="width:55px; height:55px;" alt="Didi Food">
                    </a>
                </div>
        </div>
            </div>

                <hr class="footer-divider">

                <form class="footer-form">
                <input type="email" class="form-control" placeholder="Correo electrónico" required>
                <button type="submit" class="btn btn-primary footer-btn">Enviar</button>
                </form>
                    <a href="<?= base_url('inicio'); ?>">
                        <img src="<?= base_url('assets/imagenes/logo2.png'); ?>" class="footer-logo">
                    </a>
            </div>
        <div class="footer__foot"><div class="footer__bottom"><div class="footer__copyright entry "><p>© 2025 - Tere Cazola</p></div><!-- /.footer__copyright --></div>
    </div>
</footer>

<!-- Modal para Políticas -->
<div class="modal fade" id="modalPolitica" tabindex="-1" role="dialog" aria-labelledby="modalPoliticaLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #4b0082; color: white;">
        <h5 class="modal-title" id="modalPoliticaLabel">Título</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: white;">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modalPoliticaBody">
        <!-- Contenido dinámico aquí -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<style>
.footer {
    background: #e2cef6;
    padding: 30px 0 20px;
    text-align: center;
    box-shadow: 0 4px 10px #00000015;
}

/* Título principal */
.footer-title {
    color: #4b0082;
    font-weight: 700;
    margin-bottom: 20px;
    font-size: 22px;
    letter-spacing: 1px;
}

/* Columnas */
.footer-column {
    margin-bottom: 25px;
}

.footer-heading {
    color: #4b0082;
    font-weight: 700;
    margin-bottom: 10px;
    font-size: 16px;
}

/* Listas del footer */
.footer-list {
    list-style: none;
    padding-left: 0;
    margin: 0;
}

.footer-list li {
    margin: 4px 0;
    font-size: 15px;
    color: #4b0082b3;
}

/* Enlaces */
.footer a {
    color: #6f3fa8 !important;
    text-decoration: none !important;
    font-weight: 500;
}

.footer a:hover {
    color: #4b0082 !important;
    text-decoration: underline;
}

/* Divisor */
.footer-divider {
    width: 60%;
    margin: 25px auto;
    border-top: 1px solid #c3a6df;
}

/* Formulario */
.footer-form {
    max-width: 320px;
    margin: 0 auto 20px;
}

.footer-btn {
    margin-top: 8px;
    width: 100%;
    background: #4b0082;
    border-color: #4b0082;
}

.footer-btn:hover {
    background: #36015e;
    border-color: #36015e;
}

/* Logo */
.footer-logo {
    height: 55px;
    margin-top: 15px;
    display: block;
    margin-left: auto;
    margin-right: auto;
}

/* RESPONSIVE: columnas verticales */
@media (max-width: 768px) {
    .footer-sections {
        text-align: center;
    }

    .footer-column {
        margin-bottom: 30px;
    }
}