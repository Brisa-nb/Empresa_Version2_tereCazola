<style>
  .carousel-container {
    position: relative;
    overflow: hidden;
    width: 100%;
    background-color: #fafafa;
    padding: 20px 0;
  }

  .carousel-track {
    display: flex;
    gap: 20px;
    transition: transform 0.6s ease;
  }

  .product-card {
    flex: 0 0 33.3333%; /* 3 productos visibles */
    background: white;
    border-radius: 15px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    text-align: center;
    padding: 10px;
  }

  .product-card img {
    width: 100%;
    border-radius: 10px;
  }

  .carousel-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: #4b0082;
    color: white;
    border: none;
    font-size: 24px;
    padding: 8px 12px;
    border-radius: 50%;
    cursor: pointer;
    z-index: 2;
  }

  .carousel-btn.left { left: 10px; }
  .carousel-btn.right { right: 10px; }

  .carousel-btn:hover {
    background-color: #6a0dad;
  }

  .ver-mas {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #4b0082;
    font-weight: bold;
    text-decoration: underline;
  }

  @media (max-width: 768px) {
    .product-card {
      flex: 0 0 100%; /* En móvil, uno por vista */
    }
  }
</style>

<div id="about" class="container-fluid">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:20px;">LOS FAVORITOS DEL CLIENTE</h2>

  <div class="carousel-container">
    <button class="carousel-btn left" onclick="moveSlide(-1)">&#10094;</button>
    <div class="carousel-track" id="carouselTrack">
        <?php 
        if(isset($favoritos) && !empty($favoritos)){
            foreach($favoritos as $producto){
                ?>
                <div class="product-card">
                    <img src="<?=base_url().$producto->ruta.$producto->archivo?>" alt="<?=$producto->nombre_producto?>">
                    <h4><a href="<?=base_url().'Productos/Consulta_Producto/'.$producto->idproducto?>" style="color:#4b0082;"><?=$producto->nombre_producto?></a></h4>
                    <p style="color:#4b0082;">$<?=$producto->precio?></p>
                </div>
                <?php
            }
        }
?>
    </div>

    <button class="carousel-btn right" onclick="moveSlide(1)">&#10095;</button>
  </div>

  <a href="<?= base_url('menu') ?>" class="ver-mas">Ver más productos...</a>
</div>

<script>
  const track = document.getElementById('carouselTrack');
  let cards = Array.from(track.children);
  const visibleSlides = 3;
  let index = visibleSlides;

  // Duplicar los productos al inicio y final (loop infinito)
  track.prepend(...cards.slice(-visibleSlides).map(c => c.cloneNode(true)));
  track.append(...cards.slice(0, visibleSlides).map(c => c.cloneNode(true)));
  cards = Array.from(track.children);

  // Posición inicial
  track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;

  function moveSlide(direction) {
    index += direction;
    track.style.transition = 'transform 0.6s ease';
    track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;

    track.addEventListener('transitionend', () => {
      if (index >= cards.length - visibleSlides) {
        index = visibleSlides;
        track.style.transition = 'none';
        track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;
      } else if (index <= 0) {
        index = cards.length - (visibleSlides * 2);
        track.style.transition = 'none';
        track.style.transform = `translateX(-${index * (100 / visibleSlides)}%)`;
      }
    }, { once: true });
  }
  // Autoplay
  let autoplay = setInterval(() => moveSlide(1), 1000); // cada 3s

  const container = document.querySelector('.carousel-container');

  container.addEventListener('mouseenter', () => {
    clearInterval(autoplay);
  });

  container.addEventListener('mouseleave', () => {
    autoplay = setInterval(() => moveSlide(1), 3000);
  });

</script>
