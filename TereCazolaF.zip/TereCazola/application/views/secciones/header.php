<!DOCTYPE html>
<html lang="en">
<head>
  <title>Repostería Fina Tere Cazola</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap y fuentes -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700|Lato:300,400" rel="stylesheet">
  <link rel="stylesheet" href="<?=base_url()?>assets/font-awesome-4.7.0/css/font-awesome.min.css"/>
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

  <style>
    
    body {
      font-family: 'Montserrat', sans-serif;
      margin: 0;
      padding-top: 30px;
    }

    /* Navbar */
    .navbar {
      background: linear-gradient(90deg, #4b0082, #4b0082b3);
      border: none;
      font-size: 17px;
      letter-spacing: 1px;
      box-shadow: 0 2px 8px rgba(247, 241, 241, 0.2);
      transition: all 0.3s ease;
    }

    .navbar .navbar-brand {
      padding: 0 15px;
      height: auto;
    }

    .navbar .navbar-brand .logo-img:hover {
      transform: scale(1.05);
    }

    .navbar-nav li {
      margin-right: 10px;
    }

    .navbar-nav li a {
      color: #fff !important;
      position: relative;
      padding: 10px 20px;
      text-transform: uppercase;
      transition: all 0.3s ease;
    }

    .navbar-nav li a::after {
      content: "";
      position: absolute;
      width: 0;
      height: 2px;
      left: 0;
      bottom: 0;
      background-color: #ffd900ff;
      transition: width 0.3s ease;
    }

    .navbar-nav li a:hover::after {
      width: 100%;
    }

    .navbar-nav li a:hover {
      color: #ffd700 !important;
    }

    .navbar-nav li.active > a {
      color: #ffd700 !important;
      font-weight: bold;
    }

    .navbar-nav li.active > a::after {
      width: 100%;
    }

    /* Navbar al hacer scroll */
    .navbar.scrolled {
      background: linear-gradient(90deg, #4b0082, #4b0082b3);
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }

    /* Ajustes del menú */
    .navbar-nav > li > a {
      line-height: 100px !important;
      padding-top: 0 !important;
      padding-bottom: 0 !important;
    }

    /* Imagen del banner (si se usa más adelante) */
    .banner-img img {
      max-width: 100%;
      height: 60vh;
      object-fit: cover;
      display: block;
      margin: 0 auto;
    }

    .banner-img {
      text-align: center;
      position: relative;
    }
    /* Logo container responsive */
    .logo-container {
      height: 97px;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      margin: -8px 0;
    }

    .navbar-brand .logo-img {
      height: 100%;
      width: auto;
      transition: all 0.3s ease;
    }


       /* Responsive images and card utilities */
    .responsive-img {
      max-width: 100%;
      height: auto;
      display: block;
    }

    .col-card { padding: 30px 15px; }

    .card-inner {
      background: #ffffff;
      border-radius: 15px;
      box-shadow: 0 20px 10px rgba(255,255,0,0.63);
      padding: 20px;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden; /* evita que la imagen se salga */
    }

    /* wrapper que recorta la imagen para que no sobresalga */
    .card-media {
      width: 100%;
      height: 160px;
      overflow: hidden;
      border-top-left-radius: 15px;
      border-top-right-radius: 15px;
      display: block;
      margin-bottom: 12px;
    }

    .card-media img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }
  @media screen and (max-width: 1397px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
    .btn-lg {
      width: 100%;
      margin-bottom: 35px;
    }
  }
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
    }
  }
@media (max-width: 1396px) {
  .navbar-header {
    float: none;
  }
  .navbar-toggle {
    display: block;
  }
  .navbar-collapse {
    border-top: 1px solid #eee;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
  }
  .navbar-collapse.collapse {
    display: none !important;
  }
  .navbar-nav {
    float: none !important;
    margin: 7.5px 0;
  }
  .navbar-nav > li {
    float: none;
  }
  .navbar-collapse.collapse.in {
    display: block !important;
  }
  /* Logo responsive en menú colapsado */
  .logo-container {
    height: 58.5px;
  }
  
  .navbar-brand .logo-img {
    height: 100%;
  }

  .navbar-nav > li > a {
    line-height: 70px !important; /* mantiene alineación de los enlaces */
  }
}
  </style>
</head>
<body>
  <!-- Aquí continúa tu menú -->
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

  <script>
    function cargarPolitica(tipo) {
        // Prevenir comportamiento por defecto del enlace
        if(event) event.preventDefault();
        
        // Realizar AJAX al controlador
        $.ajax({
            url: "<?=base_url()?>cargar_politica/" + tipo,
            type: "GET",
            dataType: "json",
            success: function(response) {
                if(response.error) {
                    alert("Error: " + response.error);
                } else {
                    // Actualizar el título del modal
                    $('#modalPoliticaLabel').text(response.titulo);
                    
                    // Actualizar el contenido del modal
                    $('#modalPoliticaBody').html(response.contenido);
                    
                    // Mostrar el modal
                    $('#modalPolitica').modal('show');
                }
            },
            error: function(xhr, status, error) {
                console.error("Error AJAX:", error);
                console.error("Response:", xhr.responseText);
                alert("Error al cargar la política. Por favor, intenta de nuevo.");
            }
        });
        
        return false;
    }
  </script>

  <script>
    // Efecto de scroll en la navbar
    window.addEventListener('scroll', function() {
      const navbar = document.querySelector('.navbar');
      navbar.classList.toggle('scrolled', window.scrollY > 50);
    });
  </script>
</body>
</html>