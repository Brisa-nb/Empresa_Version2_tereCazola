<!-- NUEVA SECCIÓN: Misión, Visión, valores -->
<div id="about-us" class="container-fluid" style="padding:60px 15px; background-color:#ffffff;">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:50px;">
    NUESTRA ESENCIA
  </h2>
 
  <div class="row" style="text-align:center;">

   <!-- Misión -->
    <div class="col-sm-4 col-card">
      <div class="card-inner">
        <div class="card-media">
          <img src="assets/imagenes/mision.png" alt="Misión">
        </div>
        <a href="<?=base_url('esencia/mision')?>" class="card-title">Misión</a>
      </div>
    </div>

   <!-- Visión -->
    <div class="col-sm-4 col-card">
      <div class="card-inner">
        <div class="card-media">
          <img src="assets/imagenes/vision.png" alt="Visión">
        </div>
        <a href="<?=base_url('esencia/vision')?>" class="card-title">Visión</a>
      </div>
    </div>

   <!-- Valores -->
    <div class="col-sm-4 col-card fade-up">
      <div class="card-inner">
        <div class="card-media">
          <img src="assets/imagenes/valores.png" alt="Valores">
        </div>
        <a href="<?=base_url('esencia/valores')?>" class="card-title">Valores</a>
      </div>
    </div>
 
