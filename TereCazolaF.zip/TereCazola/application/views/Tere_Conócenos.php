<!DOCTYPE html>
<html>
<head>
  <title>CONOCENOS</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
      <br>
    <br>
    <br>
    <br>
    <br>
<div style="text-align:center;">
<?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {

          // Imagen superior
            echo '
            <div style="text-align:center; margin-top:20px;">
                <img src="assets/imagenes/inicio.png" 
                    alt="Inicio" 
                    style="max-width:100%; height:auto; margin-bottom:25px;">
            </div>
';
          // Mostrar contenido HTML correctamente 
            echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' . html_entity_decode($item->contenido) . '</div>';
            echo '
            <style>
                h2 {
                    color:#4b0082;
                    font-size:1.5em;
                    text-align:center;
                    margin-top:40px;
                }

                h3 {
                    color:#4b0082;
                    font-size:1.8em;
                    text-align:center;
                    margin-bottom:10px;
                }

                .contenedor-historia {
                    margin-top:40px; 
                    font-size:1.2em; 
                    color:#4b0082; 
                    text-align:left; 
                    max-width:900px; 
                    margin-left:auto; 
                    margin-right:auto;
                }
            </style>

            <div class="contenedor-historia">
                <h2>1985</h2>
                <h3>Primera Venta</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/PrimeraVenta.png" 
                alt="Primera Venta" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    Todo comenzó en 1985, era maestra en una escuela secundaria en la ciudad de Mérida, Yucatán; 
                    sin embargo, siempre tuve una gran afición por la repostería. Un día, les comenté a mis amigas 
                    mi inquietud: necesitaba incrementar mis ingresos para solventar los gastos de mi familia, 
                    sobre todo, para la educación de mis cuatro hijos, quería que tuvieran una mejor calidad de vida 
                    de la que yo había tenido, de ahí surgió la idea de comenzar a hacer los pays que horneaba para 
                    mis amigos y familia, pero en tamaño individual, fáciles de transportar y más económicos.
                    La idea me pareció interesante, que al día siguiente después de clases y con $250 pesos de capital 
                    me dirigí a comprar los ingredientes necesarios, incluyendo los moldes individuales para prepararlos. 
                    Esa misma tarde en mi casa, salieron del horno los primeros 12 pays.
                </p>

                <h2>1991</h2>
                <h3>Apertura de la Primera Sucursal</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/PrimeraSucursal.png" 
                alt="Primera Sucursal" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    El crecimiento fue tanto que después de expandirme por casi toda mi casa, me vi en la necesidad de 
                    rentar una casa cerca de la mía, eso era muy importante, ya que podría estar cerca de mi familia, 
                    así que la adapté como una pequeña fábrica que se convirtió en la primera planta de producción, 
                    fue la primera fábrica y punto de venta oficial, donde simultáneamente se implementó el servicio a 
                    domicilio. Fue tanto el crecimiento, que aumentó la necesidad de expandirnos y buscar la manera de 
                    llegar a más personas.
                </p>

                <h2>1991</h2>
                <h3>VILLAHERMOSA</h3>
                <p>
                    Aperturamos la primera sucursal de Villahermosa ubicada en la avenida Niños Héroes. 
                    Ahora contamos con 5 sucursales en la ciudad.
                </p>

                <h2>2002</h2>
                <h3>CANCÚN</h3>
                <p>
                    Aperturamos la primera sucursal en Cancún ubicada en Avenidas. 
                    En la actualidad contamos con más de 20 sucursales en Cancún, Playa del Carmen y Tulum.
                </p>

                <h2>2004</h2>
                <h3>Apertura de la Planta Procesadora</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/PrimeraPlanta.png" 
                alt="Primera Planta" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    Seguimos creciendo y en el año 2003 construimos una fábrica de producción que fue inaugurada al año siguiente, 
                    una de las más grande en su ramo en el sureste mexicano, hoy en día contamos con una planta más grande 
                    que inauguramos en el 2021.Ese mismo año, la planta procesadora recibió el Distintivo H, un reconocimiento que 
                    otorga la Secretaría de Turismo y la Secretaría de Salud por cumplir los más altos estándares de higiene. 
                    Se ha obtenido 19 años consecutivos.
                </p>

                <h2>2006</h2>
                <h3>CAMPECHE</h3>
                <p>
                    Aperturamos la primera sucursal en Campeche ubicada en López Mateos.
                    Actualmente contamos con 11 sucursales en Campeche y CD. del Carmen.
                </p>

                <h2>2008</h2>
                <h3>Apertura Sucursal Aeropuerto</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/SucursalAeropuerto.png" 
                alt="Sucursal Aeropuerto" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    Aperturamos nuestra sucursal en el Aeropuerto de Mérida, extendiendo nuestra presencia en todo el país. 
                    A lo largo de los años, nos hemos consolidado como un ícono gastronómico en la región yucateca, convirtiéndonos 
                    en un imprescindible souvenir para quienes visitan Mérida. 
                    ¡Definitivamente, no puedes irte sin tu caja de Tere Cazola!
                </p>

                <h2>2011</h2>
                <h3>Tienda Online</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/TiendaOnline.png" 
                alt="Tienda Online" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    Debido a la demanda nacional y con la intención de brindar a nuestros clientes de otras ciudades el acceso a disfrutar 
                    de nuestros productos desde la comodidad de sus hogares, lanzamos nuestra tienda online disponible en nuestra página 
                    web www.terecazola.com, que permite hacer pedidos en línea a los clientes que viven en ciudades de la república mexicana 
                    donde no existe una sucursal.
                </p>

                <h2>2012</h2>
                <h3>CAMBIO DE IMAGEN INSTITUCIONAL</h3>
                  <div style="display:flex; justify-content:center; gap:40px; align-items:center; margin:20px 0; flex-wrap:wrap;">
                      <div style="text-align:center;">
                          <p style="font-weight:bold; color:#4b0082;">Logo Anterior</p>
                          <img src="assets/imagenes/Antiguo.png" 
                              alt="Logo Anterior" 
                              style="max-width:200px; height:auto; border-radius:10px;">
                      </div>
                      <div style="text-align:center;">
                          <p style="font-weight:bold; color:#4b0082;">Logo Actual</p>
                          <img src="assets/imagenes/Nuevo.png" 
                              alt="Logo Nuevo" 
                              style="max-width:200px; height:auto; border-radius:10px;">
                      </div>
                  </div>
                <p>
                    Renovamos la imagen de la empresa con cambios notables, destacando especialmente en la transformación del logo. 
                    Ahora, se presenta en un diseño ovalado con un fondo morado, representando una actualización significativa en nuestra 
                    identidad visual.
                </p>

                <h2>2019</h2>
                <h3>La Primera Piedra</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/PrimeraPiedra.png" 
                alt="Primera Piedra" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    En 2019, colocamos la primera piedra de la nueva Planta Procesadora de mas de 5 mil metros cuadrados, con la ilusión que 
                    traen consigo los nuevos proyectos y los planes a futuro.Desde luego, no imaginábamos que nos tocaría lidiar con el trago 
                    amargo de una pandemia que afectaría al mundo entero de diversas maneras.
                </p>

                <h2>2021</h2>
                <h3>Expansión a CDMX</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/CDMX.png" 
                alt="CDMX" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                    Ingresamos exitosamente al mercado de la CDMX, a través de dark kitchens. La demanda nos llevó a expandir nuestras operaciones 
                    con la apertura de varias sucursales para atender eficientemente las necesidades de nuestros clientes. 
                    En la actualidad nos enorgullece contar con un total de 8 sucursales.
                </p>

                <h2>2023</h2>
                <h3>GRAN INAUGURACIÓN</h3>
                <div style="text-align:center; margin:20px 0;">
                <img src="assets/imagenes/Inaguracion.png" 
                alt="Inaguracion" 
                style="max-width:100%; height:auto; border-radius:10px;">
                </div>
                <p>
                  Inauguramos con mucho orgullo la nueva planta procesadora y oficinas centrales. Este complejo industrial nos brinda la capacidad 
                  que requerimos para seguir expandiendo nuevos horizontes,construyendo nuevos proyectos de la mano de la excelencia y la calidad en 
                  los productos que elaboramos.
                </p>
            </div>
            ';
    }
} else {
    echo "No hay datos";
}
?>
</body>
</html>