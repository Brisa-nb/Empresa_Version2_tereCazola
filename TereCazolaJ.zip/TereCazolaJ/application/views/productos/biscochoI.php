<!DOCTYPE html>
<html>
<head>
  <title>BISCOCHO INGLES</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
<div style="text-align:center;">
<?php
if (!empty($nombre_clasificacion)) {
    foreach ($nombre_clasificacion as $item) {
        if ($item->nombre === "Biscocho Ingl&eacute;s") { // Solo muestra el producto deseado
            // Mostrar el nombre con el estilo solicitado
            echo '<div style="width:100%; background:rgba(75,0,130,0.7); color:#fff; text-align:center; font-size:2.5em; font-weight:bold; text-shadow:2px 2px 8px #000; padding:25px 0; margin-top:90px; position:relative; z-index:2;">';
            echo '“' . html_entity_decode($item->nombre) . '”';// nl2br convierte saltos de línea (\n) en <br> para mostrarlos en HTML
            echo '</div>';
            // Descripción y precio 
            echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' . html_entity_decode($item->descripcion) . '</div>';
            echo '<div style="margin-top:10px; font-size:1.5em; color:#f4511e; font-weight:bold;">$' . htmlspecialchars($item->precio) . ' MXN</div>';
        }
    } 
} else {
    echo "No hay datos";
}
?>
</div>
</body>
</html>
</div>
</body>
</html>