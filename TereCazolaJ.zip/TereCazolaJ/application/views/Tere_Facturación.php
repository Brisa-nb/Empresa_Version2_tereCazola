<!DOCTYPE html>
<html>
<head>
  <title>Facturacion</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
  <h1>Facturacion</h1>
</body>
</html>