<!DOCTYPE html>
<html>
<head>
  <title>CONOCENOS</title>
  <meta charset="UTF-8"> <!-- Esta línea indica que la página usa codificación UTF-8 para mostrar correctamente acentos y caracteres especiales -->
</head>
<body>
<div style="text-align:center;">
<?php
if (!empty($titulo_seccion)) {
    foreach ($titulo_seccion as $item) {
            // Título con estilo
            echo '<div style="width:100%; background:rgba(75,0,130,0.7); color:#fff; text-align:center; font-size:2.5em; font-weight:bold; text-shadow:2px 2px 8px #000; padding:25px 0; margin-top:90px; position:relative; z-index:2;">';
            echo '</div>';
            // Mostrar contenido HTML correctamente 
            echo '<div style="margin-top:30px; font-size:1.2em; color:#4b0082;">' . html_entity_decode($item->contenido) . '</div>';
    }
} else {
    echo "No hay datos";
}
?>
</body>
</html>