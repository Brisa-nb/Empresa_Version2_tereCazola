<div style=" max-width:900px; margin:80px auto 60px;padding:0 30px; espacio lateral text-align:justify;line-height:1.8;          
     color:#333;
font-size:1.1em;">
  <p>Esta historia llena de satisfacciones, como cualquier otra, no ha estado exenta de dificultades. El crecimiento del negocio también implicó retos significativos, apuestas importantes y muchas incontables horas de trabajo. No puedo omitir expresarles que ha sido un camino difícil, con muchos sacrificios y desaciertos que, a la vez los he convertido en aciertos, oportunidades, satisfacciones y muchas bendiciones.</p>

  <p>Mirando atrás con claridad, los resultados han valido la pena. Hoy Tere Cazola es una empresa socialmente responsable con 100 sucursales, más de 1,000 colaboradores y una visión permanente de crecimiento.</p>

  <p>Mantendremos, como hemos hecho desde el día 1, el compromiso de ser una empresa orgullosamente yucateca, con los más altos estándares de calidad e higiene, y un gran sentido de responsabilidad social. Tere Cazola se debe al esfuerzo y la generosidad de miles de personas, pero, sobre todo, nos debemos a nuestros clientes que, con su preferencia, nos motivan a mejorar y llegar más lejos. A todos ellos, mi profundo agradecimiento por dejarnos endulzar sus vidas.</p>

  <p>Sigamos escribiendo esta historia de sueños e ilusiones, de lucha y esperanza, de pasión y trabajo duro. Que nunca falten estos ingredientes en nuestras vidas, porque de ello depende la dulce satisfacción de alcanzar cualquier objetivo que nos propongamos lograr.</p>
</div>

<!-- Nombre centrado -->
<div id="services" class="container-fluid text-center">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:80px;">
    MARÍA TERESA CAZOLA
  </h2>
</div>