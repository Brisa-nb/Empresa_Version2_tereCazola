<footer>
  <div id="contact" class="container-fluid bg-grey" style="padding:5px 0;">
    <div class="row" style="display:flex; align-items:center;">
      <div class="col-sm-12" style="text-align:center;">
        <div style="background:#e2cef6; border-radius:0px; padding:8px; box-shadow:0 4px 10px rgba(0,0,0,0.05);">
          
          <h4 style="color:#4b0082; font-weight:bold; margin-bottom:10px;">CONTACTO</h4>
          
          <div class="row" style="display:flex; justify-content:center;">
            <div class="col-sm-4" style="color:#4b0082; font-size:0.9em;">
              <h5 style="font-weight:bold; color:#4b0082; margin-bottom:5px;">Políticas</h5>
              <ul style="list-style:none; padding-left:0; margin:0;">
                <li>Privacidad</li>
                <li>Reembolso</li>
                <li>Envío</li>
                <li>Términos</li>
                <li>Filosofía</li>
              </ul>
            </div>
            
            <div class="col-sm-4" style="color:#4b0082; font-size:0.9em;">
              <h5 style="font-weight:bold; color:#4b0082; margin-bottom:5px;">Menú</h5>
              <ul style="list-style:none; padding-left:0; margin:0;">
                <li>Inicio</li>
                <li>Tienda</li>
                <li>Menú</li>
                <li>Sucursales</li>
                <li>Conócenos</li>
              </ul>
            </div>
            
            <div class="col-sm-4" style="color:#4b0082; font-size:0.9em;">
              <h5 style="font-weight:bold; color:#4b0082; margin-bottom:5px;">Información</h5>
              <ul style="list-style:none; padding-left:0; margin:0;">
                <li><span class="glyphicon glyphicon-map-marker"></span> Mérida, México</li>
                <li><span class="glyphicon glyphicon-phone"></span> +52 999 123 4567</li>
                <li><span class="glyphicon glyphicon-envelope"></span> contacto@terecazola.com</li>
              </ul>
            </div>
          </div>

          <hr style="margin:10px auto; width:60%;">

          <form style="max-width:300px; margin:10px auto;">
            <input type="email" class="form-control" placeholder="Correo electrónico" required>
            <button type="submit" class="btn btn-primary" style="margin-top:5px;">Enviar</button>
          </form>

          <a href="<?php echo base_url('Inicio'); ?>">
            <img src="<?php echo base_url('assets/imagenes/logo2.png'); ?>" alt="Logo Tere Cazola" style="height:50px; margin-top:10px;">
          </a>

        </div>
      </div>
    </div>
  </div>
</footer>
