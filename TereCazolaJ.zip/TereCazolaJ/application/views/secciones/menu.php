<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="<?php echo base_url('inicio'); ?>">
    <img src="<?php echo base_url('assets/imagenes/logo.png'); ?>" alt="Tere Cazola" style="height:70px;">
</a>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?=base_url('inicio')?>">INICIO</a></li>
        <li><a href="<?=base_url('tiendal')?>">TIENDA EN LÍNEA</a></li>
        <li><a href="<?=base_url('menu')?>">MENÚ</a></li>
        <li><a href="<?=base_url('blog')?>">BLOG</a></li>
        <li><a href="<?=base_url('sucursales')?>">SUCURSALES</a></li>
        <li><a href="<?=base_url('conocenos')?>">CONOCENOS</a></li>
        <li><a href="<?=base_url('contacto')?>">CONTACTO</a></li>
        <li><a href="<?=base_url('facturacion')?>">FACTURACIÓN</a></li>
      </ul>
    </div>
</nav>