<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:20px;">LOS FAVORITOS DEL CLIENTE</h2>
  <div class="row" style="text-align:center;">
    <div class="col-sm-3">
      <img src="assets/imagenes/hojaldras.jpg" alt="Hojaldras" style="width:100%; border-radius:10px;">
      <h4 style="font-weight:bold; margin-top:15px;"><li><a href="<?=base_url('productos/hojaldra')?>"style="color:#4b0082;">HOJALDRAS</a></li></h4>
      <p style="color:#4b0082;">$120.00 MXN</p>
    </div>
    <div class="col-sm-3">
      <img src="assets/imagenes/rosca.jpg" alt="Rosca Brioche Extra Queso" style="width:100%; border-radius:10px;">
      <h4 style="font-weight:bold; margin-top:15px;"><li><a href="<?=base_url('productos/roscaB')?>"style="color:#4b0082;">ROSCA BRIONCHE EXTRA QUESO</a></li></h4>
      <p style="color:#4b0082;">$295.00 MXN</p>
    </div>
    <div class="col-sm-3">
      <img src="assets/imagenes/bizcocho.jpg" alt="Biscocho Inglés" style="width:100%; border-radius:10px;">
      <h4 style="color:#4b0082; font-weight:bold; margin-top:15px;"><li><a href="<?=base_url('productos/biscochoI')?>"style="color:#4b0082;">BISCOCHO INGLES</a></li></h4>
      <p style="color:#4b0082;">$180.00 MXN</p>
    </div>
    <div class="col-sm-3">
      <img src="assets/imagenes/bolitas.jpg" alt="Bolitas de Queso" style="width:100%; border-radius:10px;">
      <h4 style="font-weight:bold; margin-top:15px;"><li><a href="<?=base_url('productos/bolitasQ')?>"style="color:#4b0082;">BOLITAS DE QUESO</a></li></h4>
      <p style="color:#4b0082;">$150.00 MXN</p>
    </div>
     <div style="text-align:center; margin-top:20px;">
      <a href="<?= base_url('menu') ?>" style="color:#4b0082; font-weight:bold; text-decoration:underline;"> Ver más productos...
      </a>
      </div>
  </div>
</div>
 