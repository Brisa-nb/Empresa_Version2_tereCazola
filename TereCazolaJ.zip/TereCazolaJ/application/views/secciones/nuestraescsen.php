<!-- NUEVA SECCIÓN: Misión, Visión, valores -->
<div id="about-us" class="container-fluid" style="padding:60px 15px; background-color:#f9f9f9;">
  <h2 style="text-align:center; color:#4b0082; font-weight:bold; margin-bottom:50px;">
    NUESTRA ESENCIA
  </h2>
 
  <div class="row" style="text-align:center;">
 
   <!-- Misión -->
    <div class="col-sm-4" style="padding:20px;">
    <div style="background:white; border-radius:15px; box-shadow:0 20px 10px rgba(0,0,0,0.1); padding:30px; height:100%; text-align:center;">
    <img src="assets/imagenes/mision.png" alt="Misión" style="width:300px; margin-bottom:20px;">
    <a href="<?=base_url('esencia/mision')?>" style="color:#4b0082; font-size:28px; font-weight:bold; text-decoration:none; display:block;">Misión
    </a>
  </div>
</div>
   <!-- Visión -->
    <div class="col-sm-4" style="padding:20px;">
    <div style="background:white; border-radius:15px; box-shadow:0 20px 10px rgba(0,0,0,0.1); padding:30px; height:100%; text-align:center;">
    <img src="assets/imagenes/vision.png" alt="Visión" style="width:300px; margin-bottom:20px;">
    <a href="<?=base_url('esencia/vision')?>" style="color:#4b0082; font-size:28px; font-weight:bold; text-decoration:none; display:block;">Visión
    </a>
  </div>
</div>
   <!-- Valores -->
    <div class="col-sm-4 fade-up" style="padding:20px;">
    <div style="background:white; border-radius:15px; box-shadow:0 20px 10px rgba(0,0,0,0.1); padding:30px; height:100%; text-align:center;">
    <img src="assets/imagenes/valores.png" alt="Valores" style="width:300px; margin-bottom:20px;">
    <a href="<?=base_url('esencia/valores')?>" style="color:#4b0082; font-size:28px; font-weight:bold; text-decoration:none; display:block;">Valores
    </a>
  </div>
</div>
 
