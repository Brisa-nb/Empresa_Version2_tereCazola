<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Productos extends CI_Controller {
      public function __construct() {
        parent::__construct();
        $this->load->model('mP'); // Carga el modelo
    }
    
    public function roscaB(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['nombre_clasificacion'] = $this->mP->consultar_clasificacion(9);
        $this->load->view('productos/roscaB', $datos); // Pasa los datos a la vista
        $this->load->view('secciones/footer');
    }

    public function hojaldra(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['nombre_clasificacion']=$this->mP->consultar_clasificacion(14);
	    $this->load->view('productos/hojaldra',$datos); 
        $this->load->view('secciones/footer');
    } 

    public function bolitasQ(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['nombre_clasificacion']=$this->mP->consultar_clasificacion(14);
	    $this->load->view('productos/bolitasQ',$datos);
        $this->load->view('secciones/footer'); 
    } 

    public function biscochoI(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['nombre_clasificacion']=$this->mP->consultar_clasificacion(10);
	    $this->load->view('productos/biscochoI',$datos); 
        $this->load->view('secciones/footer');
    } 
}