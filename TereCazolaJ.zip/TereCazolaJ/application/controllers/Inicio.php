<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inicio extends CI_Controller {
    public function __construct(){
    parent::__construct();
    $this->load->model('mP');
}
    public function index(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $this->load->view('secciones/baner');
        $this->load->view('secciones/losfav');
        $this->load->view('secciones/legado');
        $this->load->view('secciones/reconocido');
        $this->load->view('secciones/40años');
        $this->load->view('secciones/nuestraescsen');
        $this->load->view('secciones/terexd');
        $this->load->view('secciones/footer');
    }

    public function tiendal(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(2);
        $this->load->view('Tere_TiendaL',$datos);
        $this->load->view('secciones/footer');
    } 

    public function menu(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(3);
	    $this->load->view('Tere_Menú',$datos);
        $this->load->view('secciones/footer');
    } 

    public function blog(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(7);
	    $this->load->view('Tere_Blog',$datos);
        $this->load->view('secciones/footer'); 
    } 

    public function sucursales(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(4);
	    $this->load->view('Tere_Sucursales',$datos);
        $this->load->view('secciones/footer');
    } 

    public function conocenos(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(5);
	    $this->load->view('Tere_Conócenos',$datos);
        $this->load->view('secciones/footer');
    } 

    public function contacto(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $datos['titulo_seccion']=$this->mP->consultar_seccion(6);
	    $this->load->view('Tere_Contacto',$datos);
        $this->load->view('secciones/footer');   
    } 

    public function facturacion(){
        $this->load->view('secciones/header');
        $this->load->view('secciones/menu');
        $this->load->view('Tere_Facturación');
        $this->load->view('secciones/footer');
    } 
}
