<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-06 01:47:05 --> Severity: error --> Exception: No se puede establecer una conexión ya que el equipo de destino denegó expresamente dicha conexión C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 01:47:20 --> Severity: error --> Exception: No se puede establecer una conexión ya que el equipo de destino denegó expresamente dicha conexión C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 01:50:50 --> Severity: error --> Exception: No se puede establecer una conexión ya que el equipo de destino denegó expresamente dicha conexión C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 02:14:30 --> 404 Page Not Found: Parisjpg/index
ERROR - 2025-09-06 02:14:30 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-06 02:14:30 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-06 02:28:33 --> 404 Page Not Found: Parisjpg/index
ERROR - 2025-09-06 02:28:33 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-06 02:28:33 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-06 02:32:21 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-06 02:32:21 --> 404 Page Not Found: Sanfranjpg/index
