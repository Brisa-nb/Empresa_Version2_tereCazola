<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-08-30 00:41:23 --> 404 Page Not Found: Welcome/principal
ERROR - 2025-08-30 00:49:39 --> Severity: error --> Exception: syntax error, unexpected variable "$datos", expecting "function" or "const" C:\xampp\htdocs\empresa\application\controllers\Welcome.php 31
ERROR - 2025-08-30 02:15:44 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\models\Pagina_model.php 7
ERROR - 2025-08-30 02:15:58 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\models\Pagina_model.php 7
ERROR - 2025-08-30 02:17:32 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\models\Pagina_model.php 7
ERROR - 2025-08-30 02:17:41 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\models\Pagina_model.php 7
ERROR - 2025-08-30 02:17:43 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\models\Pagina_model.php 7
ERROR - 2025-08-30 02:18:45 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\models\Pagina_model.php 7
